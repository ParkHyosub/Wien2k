#!/bin/sh -x

# TODO:
# 1. clean all CVS files
# 2. clean all Makefiles from makedepend-entry

CleanMakedepend() {
    # usage: $0 makefile
    dir=`dirname $1`
    cp $1 $dir/Makefile.bck
    awk 'BEGIN {nodepend=1;}
/^# DO NOT DELETE/ { nodepend=0; }
/a*/ { if (nodepend) print; }' $dir/Makefile.bck > $1
    rm -f $dir/Makefile.bck
}
    
if test $# -ne 3 ; then
    echo "
  Usage: $0 topdir in-tarball suffix
"
    exit 1
fi

TOPDIR=$1
INTAR=$2
SUFFIX=$3
VERSION=`cat $TOPDIR/version`
# this is for version Beta-1.0
if test "`grep Beta- $TOPDIR/version`" != "" ; then
    VERSION=-B${VERSION#Beta-}
fi
DIRNAME=XCrySDen-${VERSION}-${SUFFIX}

if test ! -d $TOPDIR ; then
    echo "TOPDIR directory \"$TOPDIR\" does not exists !!!"
    exit 1
fi
if test ! -f $INTAR ; then
    echo "tar-ball file \"$INTAR\" does not exists !!!"
    exit 1
fi

cd $TOPDIR
mkdir $DIRNAME
if test ! -d $DIRNAME ; then
    echo "DIRNAME directory \"$DIRNAME\" does not exists !!!"
    exit 1
fi
mv $INTAR $DIRNAME/
cd $DIRNAME
tar xvf $INTAR; rm -f $INTAR

# clean CVS files
find . -name CVS -exec /bin/rm -r {} \;

# clean all Makefiles from makedepend-entry
for make in `find . | grep Makefile`; do
    CleanMakedepend $make
done

cd ..
tar cvf $DIRNAME.tar $DIRNAME/
gzip $DIRNAME.tar
rm -rf $DIRNAME/


#VERSION=`cat ../version`
#DIR=XCrySDen$VERSION
#
#HERE=$PWD
#DIR=""
#if test "$#" = 0 ; then
#    version=`cat $XCRYSDEN_TOPDIR/version`
#    DIR=`(cd $XCRYSDEN_TOPDIR/..; ls -rt | grep XCrySDen | tail -1)`
#    TGZ=`ls -rt *.gz | grep $DIR | tail -1`
#    tail=${TGZ#$DIR}    
#
#    if test "$TGZ" = "" ; then
#    # no sutiable file for repackaging
#	echo "No sutiable file for repackaging !!!"
#	exit 0
#    fi
#    mv $TGZ /tmp
#else
#    TGZ=$1
#    if test ! -f $TGZ ; then
#	echo "File \"$TGZ\" does not exists !!!"
#    fi    
#    cp $TGZ /tmp
#fi
#
#cd /tmp
#tar zxvf $TGZ
#
#if test "$DIR" = "" ; then    
#    DIR=`(ls -rt | grep XCrySDen | tail -1)`
#    version=`cat $DIR/version`
#    tail=${TGZ#$DIR}    
#fi    
#
#mv $DIR XCrySDen${version}
#tar zcvf XCrySDen${version}${tail} XCrySDen${version}/
#rm -rf /tmp/XCrySDen${version} /tmp/$TGZ
#
#mv XCrySDen${version}${tail} $HERE