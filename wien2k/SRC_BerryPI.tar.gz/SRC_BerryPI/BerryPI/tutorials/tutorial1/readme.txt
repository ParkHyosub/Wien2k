Follow this link for a detailed discription:
https://github.com/spichardo/BerryPI/wiki/Tutorial-1:-Spontaneous-Polarization-in-BaTiO3
