#include <sys/resource.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <signal.h>

/* 
This code has two parts. The first is equivalent of the shell script
   ulimit -s unlimited (in bash)
   limit stacksize unlimited (in csh)

It will overcome problems when either the user forgets to do this (or
does not know that they have to), or mpi implimentations that do not
use ssh/rsh and thereby circumvent a ulimit/limit command

The second has some error handlers for standard signals. The type definition
of these signals is not quite right, but they work (at present they will
give a compile warning).

L. D. Marks, Jan 2010

Caveat: I don't like C!
*/

/* Global array for signal. The use of an array avoids
messy C -> Fortran issues */

long wsig[1] ;


void hackstack_()
{
  struct rlimit limit;
  int i ;

/* Get the current stacksize limit */
  if (getrlimit(RLIMIT_STACK, &limit) != 0) {
    printf("getrlimit() failed with errno=%d\n", errno);
    exit(1);
  }
/* Set to the maximum we can */
  limit.rlim_cur = RLIM_INFINITY; /* rlimit.rlim_max; */

  if (setrlimit(RLIMIT_STACK, &limit) != 0) {
    printf("setrlimit() failed with errno=%d\n", errno);
    exit(1);
  }

}

void hackstack()
{
hackstack_() ;
}

/* Code for signals */

/* Note the "_" after the calls. It would be better to use autoconf to
determine what we need here. There could be some portability issues  */

/* At least in ifort one could use !DEC Attributes C (or similar) to
ensure that w2ksigtrap in W2kinit.F has no "_" */

/* These probably should not be "void" */

__sighandler_t w2ksignal_int (int signum, __sighandler_t h)
{
wsig[0] = 1 ;
w2ksigtrap_(wsig) ;
return SIG_DFL ;
}

__sighandler_t w2ksignal_ill (int signum, __sighandler_t h)
{
wsig[0] = 2 ;
w2ksigtrap_(wsig) ;
return SIG_DFL ;
}

__sighandler_t w2ksignal_iot (int signum, __sighandler_t h)
{
wsig[0] = 3 ;
w2ksigtrap_(wsig) ;
return SIG_DFL ;
}

__sighandler_t w2ksignal_bus (int signum, __sighandler_t h)
{
wsig[0] = 4 ;
w2ksigtrap_(wsig) ;
return SIG_DFL ;
}

__sighandler_t w2ksignal_fpe (int signum, __sighandler_t h)
{
wsig[0] = 5 ;
w2ksigtrap_(wsig) ;
return SIG_DFL ;
}

__sighandler_t w2ksignal_sigsev (int signum, __sighandler_t h)
{
wsig[0] = 6 ;
w2ksigtrap_(wsig) ;
return SIG_DFL ;
}

__sighandler_t w2ksignal_stack (int signum, __sighandler_t h)
{
wsig[0] = 7 ;
w2ksigtrap_(wsig) ;
return SIG_DFL ;
}

__sighandler_t w2ksignal_cpu (int signum, __sighandler_t h)
{
wsig[0] = 8 ;
w2ksigtrap_(wsig) ;
return SIG_DFL ;
}

__sighandler_t w2ksignal_kill (int signum, __sighandler_t h)
{
wsig[0] = 9 ;
w2ksigtrap_(wsig) ;
return SIG_DFL ;
}

__sighandler_t w2ksignal_term (int signum, __sighandler_t h)
{
wsig[0] = 10 ;
w2ksigtrap_(wsig) ;
return SIG_DFL ;
}

__sighandler_t w2ksignal_hup (int signum, __sighandler_t h)
{
wsig[0] = 11 ;
w2ksigtrap_(wsig) ;
return SIG_DFL ;
}


void w2ksignals ()
{
/* Set the signals, assuming that the parameters have been defined for us */

#ifdef SIGINT
        signal ( SIGINT, (__sighandler_t) w2ksignal_int );  /* Interrupt */
#endif
#ifdef SIGILL
        signal ( SIGILL, (__sighandler_t) w2ksignal_ill ); /* Illegal Instruction */
#endif
#ifdef SIGIOT
        signal ( SIGIOT, (__sighandler_t) w2ksignal_iot ); /* IOT Trap */
#endif
#ifdef SIGBUS
        signal ( SIGBUS, (__sighandler_t) w2ksignal_bus ); /* Bus Error */
#endif
#ifdef SIGFPE
        signal ( SIGFPE, (__sighandler_t) w2ksignal_fpe ); /* Floating-point exception */
#endif
#ifdef SIGSEV
        signal ( SIGSEV, (__sighandler_t) w2ksignal_sigsev );/* SIGSEV */
#endif
#ifdef SIGSTKFLT
        signal ( SIGSTKFLT, (__sighandler_t) w2ksignal_stack );/* Stack Fault */
#endif
#ifdef SIGXCPU
        signal ( SIGXCPU, (__sighandler_t) w2ksignal_cpu ) ;/* CPU limit*/
#endif
#ifdef SIGKILL
        signal ( SIGKILL, (__sighandler_t) w2ksignal_kill ) ;/* Kill*/
#endif
#ifdef SIGTERM
        signal ( SIGTERM, (__sighandler_t) w2ksignal_term ) ;/* Termination*/
#endif
#ifdef SIGHUP
        signal ( SIGHUP, (__sighandler_t) w2ksignal_hup ) ;/* Hang Up*/
#endif

}

void w2ksignals_ ()
{
w2ksignals() ;
}
