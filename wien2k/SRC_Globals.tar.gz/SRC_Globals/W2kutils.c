/* Utility functions for tasks difficult to do in Fortran.
 * This requires the usual caution with underscores in function names.
 *
 * This code has two parts.
 *
 * Part 1: Extend stack size, i.e., the equivalent of:
 * 
 *    bash$ ulimit -s unlimited
 *    csh$  limit stacksize unlimited
 * 
 *	This is needed when either the user forgets to do so (or does not know
 *	that they have to), or for mpi implimentations that do not use ssh/rsh
 *	for remote starters and thereby miss system-customized limits.
 * 
 * Part 2: Define handlers for standard and not-so-standard signals.
 * 
 * L. D. Marks, Jan 2010; Michael Sternberg, 2010, 2012
*/

#include <sys/types.h>		/* getpid */
#include <unistd.h>

#include <sys/resource.h>	/* getrlimit/setrlimit */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <signal.h>

#include "W2kutils.h"

/* Part 1 - extend stack size */
void w2k_extend_limits_() {
     w2k_extend_limits ();
}

void w2k_extend_limits()
{
    struct rlimit limit;

    /* Get current limit */
    if (getrlimit(RLIMIT_STACK, &limit) != 0) {
        perror("getrlimit(): WARNING: Cannot find stack limits, continuing");
    }

    /* Set to the maximum we can */
    /* Some systems do not allow RLIM_INFINITY */
    /* Extend to current hard limit ("ulimit -S -s hard" in bash) */
#ifdef __APPLE__
    limit.rlim_cur = limit.rlim_max ; /* RLIM_INFINITY */
#else
    limit.rlim_cur = RLIM_INFINITY ;
#endif

    if (setrlimit(RLIMIT_STACK, &limit) != 0) {
        perror("setrlimit(): WARNING: Cannot raise stack limit, continuing");
    }
}


/* Part 2 - Pass signals to custom handler in Fortran. */
/*
   From signal(7) on Linux 2.6:

       ... signals described in the original POSIX.1-1990 standard.

       Signal	  Value	    Action   Comment
       -------------------------------------------------------------------------
       SIGHUP	     1	     Term    Hangup detected on controlling terminal
				     or death of controlling process
       SIGINT	     2	     Term    Interrupt from keyboard
       SIGQUIT	     3	     Core    Quit from keyboard
       SIGILL	     4	     Core    Illegal Instruction
       SIGABRT	     6	     Core    Abort signal from abort(3)
       SIGFPE	     8	     Core    Floating point exception
       SIGKILL	     9	     Term    Kill signal
       SIGSEGV	    11	     Core    Invalid memory reference
       SIGPIPE	    13	     Term    Broken pipe: write to pipe with no readers
       SIGALRM	    14	     Term    Timer signal from alarm(2)
       SIGTERM	    15	     Term    Termination signal
       SIGUSR1	 30,10,16    Term    User-defined signal 1
       SIGUSR2	 31,12,17    Term    User-defined signal 2
       SIGCHLD	 20,17,18    Ign     Child stopped or terminated
       SIGCONT	 19,18,25    Cont    Continue if stopped
       SIGSTOP	 17,19,23    Stop    Stop process
       SIGTSTP	 18,20,24    Stop    Stop typed at tty
       SIGTTIN	 21,21,26    Stop    tty input for background process
       SIGTTOU	 22,22,27    Stop    tty output for background process

       The  signals SIGKILL and SIGSTOP cannot be caught, blocked, or ignored.

       Next the signals not in the  POSIX.1-1990  standard  but	 described  in
       SUSv2 and POSIX.1-2001.

       Signal	    Value     Action   Comment
       -------------------------------------------------------------------------
       SIGBUS	   10,7,10     Core    Bus error (bad memory access)
       SIGPOLL		       Term    Pollable event (Sys V). Synonym of SIGIO
       SIGPROF	   27,27,29    Term    Profiling timer expired
       SIGSYS	   12,-,12     Core    Bad argument to routine (SVr4)
       SIGTRAP	      5	       Core    Trace/breakpoint trap
       SIGURG	   16,23,21    Ign     Urgent condition on socket (4.2BSD)
       SIGVTALRM   26,26,28    Term    Virtual alarm clock (4.2BSD)
       SIGXCPU	   24,24,30    Core    CPU time limit exceeded (4.2BSD)
       SIGXFSZ	   25,25,31    Core    File size limit exceeded (4.2BSD)


       Next various other signals.

       Signal	    Value     Action   Comment
       --------------------------------------------------------------------
       SIGIOT	      6	       Core    IOT trap. A synonym for SIGABRT
       SIGEMT	    7,-,7      Term

       SIGSTKFLT    -,16,-     Term    Stack fault on coprocessor (unused)
       SIGIO	   23,29,22    Term    I/O now possible (4.2BSD)
       SIGCLD	    -,-,18     Ign     A synonym for SIGCHLD
       SIGPWR	   29,30,19    Term    Power failure (System V)
       SIGINFO	    29,-,-	       A synonym for SIGPWR
       SIGLOST	    -,-,-      Term    File lock lost
       SIGWINCH	   28,28,20    Ign     Window resize signal (4.3BSD, Sun)
       SIGUNUSED    -,31,-     Term    Unused signal (will be SIGSYS)

       (Signal 29 is SIGINFO / SIGPWR on an alpha but SIGLOST on a sparc.)

       SIGEMT  is  not	specified in POSIX.1-2001, but nevertheless appears on
       most other Unices, where its default action is typically	 to  terminate
       the process with a core dump.

       SIGPWR (which is not specified in POSIX.1-2001) is typically ignored by
       default on those other Unices where it appears.

       SIGIO (which is not specified in POSIX.1-2001) is ignored by default on
       several other Unices.
*/
static int signals_handled[] = {
		    SIGINT,
		    SIGILL,
#ifdef SIGIOT
		    SIGIOT,
#endif
#ifdef SIGBUS
		    SIGBUS,
#endif
		    SIGFPE,
		    SIGSEGV,
#ifdef SIGSTKFLT
		    SIGSTKFLT,
#endif
#ifdef SIGXCPU
		    SIGXCPU,
#endif
		    SIGTERM,
		    SIGHUP,
		    0,		/* terminator - required */
	};

void w2k_edit_signals (int in_signal)
{
/* Register/de-register custom handler for all of signals_handled[].
 *
 * Meaning of argument:
 *  in_signal == 0: Register known signals.
 *  in_signal > 0:  De-register the signals.
 *		    NB: Reset to SIG_IGN, not SIG_DFL, so as not to risk
 *		    stopping the program before the first handler reached
 *		    MPI_ABORT.
 */

    struct sigaction new_action, old_action;
    int i, signum;
    int do_init = (in_signal == 0);
    char *msg = do_init ? "w2k_edit_signals(): installed"
			: "w2k_edit_signals(): reset"
			;

    new_action.sa_handler = do_init ? w2k_dispatch_signal : SIG_IGN;
    new_action.sa_flags = 0;
    sigemptyset (&new_action.sa_mask);

    /* install new handlers unless signal was previously ignored */
    for (i = 0; (signum = signals_handled[i]); ++i) {
	sigaction (signum, NULL, &old_action);
	if (old_action.sa_handler == SIG_IGN) {
#ifdef TEST_W2k
	    psignal(signum, "w2k_edit_signals(): -ignored-");
#endif
	    continue;
	}

	sigaction (signum, &new_action, NULL);
#ifdef TEST_W2k
	psignal(signum, msg);
#endif
    }
}

void w2k_register_signals_() { w2k_edit_signals(0); }
void w2k_register_signals () { w2k_edit_signals(0); }

void w2k_dispatch_signal (int signum)
{
/* The custom handler for all signals in signals_handled[].
 *
 * This handler is to be called *once* when any of the signals are received.
 * The intent is to eventually call MPI_ABORT(), which is done by upcalling,
 * from the C signal handler, the secondary Fortran handler
 * w2k_catch_signal_(), which will reach MPI_ABORT().
 *
 * Caution: The w2k_catch_signal_() upcall *must* terminate the program or
 * otherwise it needs SIGKILL.
 */

    static long wsig;		/* data type for C-Fortran interaction. */

    /* immediately reset, making this a one-time-only handler; then announce. */
    w2k_edit_signals(signum);
    psignal(signum, "w2k_dispatch_signal(): received");

    /* convert system signals numbers to W2k (pedestrian assoc. array) */
    switch (signum) {
        case SIGINT:	wsig = 1;	break;
        case SIGILL:	wsig = 2;	break;
	case SIGABRT:	wsig = 3;	break;
#ifdef SIGBUS
        case SIGBUS:	wsig = 4;	break;
#endif
        case SIGFPE:	wsig = 5;	break;
        case SIGSEGV:	wsig = 6;	break;
#ifdef SIGSTKFLT
        case SIGSTKFLT:	wsig = 7;	break;
#endif
#ifdef SIGXCPU
        case SIGXCPU:	wsig = 8;	break;
#endif
        /* SIGKILL never reaches user code */
        case SIGTERM:	wsig = 10;	break;
        case SIGHUP:	wsig = 11;	break;
#ifdef SIGIOT
#if SIGIOT != SIGABRT
        case SIGIOT:	wsig = 12;	break;
#endif
#endif
	default:	wsig = 0;	break;	/* should not happen */
    }

    /* upcall Fortran handler, which will attempt MPI teardown and MUST stop */
    w2k_catch_signal_(&wsig);
}

#ifdef TEST_W2k
/* internal test routine: ping each signal handler */
void w2k_test_signals_() {
     w2k_test_signals();
}
void w2k_test_signals()
{
    printf("\nTesting internal signal handlers ...\n");
    int i, signum;
    for (i = 0; (signum = signals_handled[i]); ++i) {
	printf("\nRaising signal %d.\n", signum);
	raise(signum);
    }
    printf("\nI am PID %ld\n", (long) getpid());
}
#endif
