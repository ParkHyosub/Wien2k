/* Extend stack size, called from Fortran */
void w2k_extend_limits_(void);
void w2k_extend_limits (void);

/* Set handlers in C, called from Fortran */
void w2k_register_signals_(void);
void w2k_register_signals (void);

/* convenience definition; see signal(2) on Linux and signal(3) on BSD */
typedef void (*sighandler_t) (int);

/* Translate C signal numbers to WIEN's numbers; C-internal */
void w2k_dispatch_signal (int signum);

/* internal test routine: ping each signal handler */
void w2k_test_signals_(void);
void w2k_test_signals (void);

/* Final handler, Fortran-only in production version */
void w2k_catch_signal_(long *);
void w2k_catch_signal (long *);
