#!/usr/bin/perl

require "../../libs/w2web.pl";

&GetInput;
&GetSession;

$OUT = <<__STOP__;
<h3>Activate core density superposition</h3>

<p>
The presence of <b>.lcore</b> activates the core density superposition. It creates case.clmsc (instead of case.clmcor) and is useful when you have some charge "leackage", but don't want to include this state as semi-core.
</p>

<p>
No, I don't want that, <A HREF="/util/delete.pl?SID=$SID&file=$DIR/.lcore">remove file .lcore</A>.
</p>


__STOP__

$umps = qx( cd $DIR; touch .lcore );

$OUT .= <<__STOP__;
$umps
</pre>
__STOP__


PrintPage("testpara", $OUT);
