#!/usr/bin/perl

require "../../libs/w2web.pl";
require "../../libs/struct.pl";

&GetInput;
&GetSession;

if ( ($nx ne "") && ($ny ne "") && ($nz ne "") && ($nrx ne "") && ($nry ne "") && ($nrz ne "" ) ) {

    $nxtest=int($nx / $nrx ) *$nrx;
    $nytest=int($ny / $nry ) *$nry;
    $nztest=int($nz / $nrz ) *$nrz;
    if ( ($nxtest == $nx ) && ($nytest == $ny ) && ($nztest == $nz ) ) {
	$ups = qx( cd $DIR; echo "0\n $nx \n $ny \n $nz \n $nrx \n $nry \n $nrz \n" | run_kgenhf_lapw -redklist   );

	$OUT .= <<__STOP__;
<h3>run_kgenhf_lapw -redklist < 0 $nx $ny $nz $nrx $nry $nrz in  $DIR</h3>

was used to create the k-mesh for a full-hybrid calculation.
<br>
__STOP__

      } else {
	$OUT .= <<__STOP__;
<b>The reduced k-mesh must be commensurate with the full mesh </b>(like 4x4x4 / 2x2x2); but not (4x4x4 / 3x3x3) ...
__STOP__
      }
} else {
	$OUT .= <<__STOP__;
<b>You have to specify the k-mesh with 6 numbers for nx,ny, ...</b>
__STOP__
}
	$OUT .= <<__STOP__;
<br>	<td bgcolor=$green>
<FORM ACTION="/exec/next.pl" METHOD=POST>
<INPUT TYPE=HIDDEN NAME=nexturl VALUE="$nexturl">
<INPUT TYPE=submit VALUE="$FORM{'next'}">
</FORM>
	</td>
__STOP__


PrintPage("xyz2struct", $OUT);
