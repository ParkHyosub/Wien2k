#!/usr/bin/perl

require "../../libs/w2web.pl";
require "../../libs/struct.pl";
$doit=0;

&GetInput;
&GetSession;

$file="$DIR/$xyzfil";
$next="cont with xyz2struct";
$nexturl="/util/xyz2struct.pl?SID=$SID&xyzfil=$xyzfil";

#if (!$doit) {

#$OUT = <<__STOP__;
#<h3>Rename file</h3>

#Rename <b>$file</b> 
#<FORM ACTION="/util/xyz2struct.pl" METHOD=POST>
#<INPUT TYPE=HIDDEN NAME="file" VALUE="$file">
#<INPUT TYPE=HIDDEN NAME="SID" VALUE="$SID">
#<INPUT TYPE=HIDDEN NAME="doit" VALUE="1">
#to <INPUT NAME="newfile"><br>
#<br>
#<INPUT TYPE=SUBMIT VALUE="rename it">
#</FORM>
#
#__STOP__
#
#} else {

	$umps = qx( cd $DIR; xyz2struct < $file ; cp xyz2struct.struct $CASE.struct  );

	$OUT = <<__STOP__;
<h3>xyz2struct</h3>

<b>$file</b> was used to create <b>$DIR/$CASE.struct</b>.
<br>
__STOP__
    $umps=~s/\n/<br>/sig;
    $umps=~s&Lattice parameters not specified&<b>Lattice parameters not specified</b>&sig;
$OUT.="<tt>$umps</tt>";
$OUT.=<<__STOP__;
<FORM ACTION="/util/edit.pl">
<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT NAME=file VALUE="$file" TYPE=HIDDEN>
<INPUT NAME=redir VALUE="/util/xyz2struct.pl?SID=$SID?xyzfil=$xyzfil" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="edit $xyzfil">
 (insert lattice parameters, remove "cluster"-atoms, when WARNINGS appeared)
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
__STOP__

#}


PrintPage("xyz2struct", $OUT);
