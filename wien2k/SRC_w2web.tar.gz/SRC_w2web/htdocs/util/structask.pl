#!/usr/bin/perl

require "../../libs/w2web.pl";
require "../../libs/struct.pl";
$debug=0;
&GetInput;
&GetSession;

$upload ="ul&nbsp;";
$upload = "<img src=/art/ul.gif BORDER=0 ALT=\"upload\">";

if ($doit) {
# check for cif file
	$file="$DIR/$ciffil";
	$file1="$DIR/$txtfil";
#        $umps = qx(echo $file > $DIR/mistfile);
	if ( -e $file && -s $file && ($ciffil ne "") ) {  
		$umps = qx( cd $DIR; cp $ciffil $CASE.cif; $WIENROOT/cif2struct $CASE.cif > $CASE.outputcif2struct; rm $CASE.cif);
		$numatoms=qx(cd $DIR; grep ATOMS $CASE.struct | cut -c28-30);
        } elsif ( -e $file1 && -s $file1 && ($txtfil ne "") ) {  
		$umps = qx( cd $DIR; cp $txtfil $CASE; $WIENROOT/cif2struct $CASE > $CASE.outputcif2struct; rm $CASE);
		$numatoms=qx(cd $DIR; grep ATOMS $CASE.struct | cut -c28-30);
        } else {
	# generate struct file...
	$umps = qx( cd $DIR;cp $WIENROOT/SRC_templates/template.struct $CASE.struct);
        }

# immediately copy it to _i so we directly start in edit mode
	$structfile = "$DIR/$CASE.struct";
	$testfile = "$DIR/$CASE.struct_i";
	$umps = qx( cd $DIR;cp $structfile $testfile );
	&StructRead;
#set s_lattice, otherwise spacegroup will not be called
        $s_spacegr=~ s/ /_/;
	$s_nato=$numatoms;
        foreach $v (@lattype) {
          if ( $s_spacegr =~ /$v/ ) {
		$s_lattice = $s_spacegr;
	  } 
        }
        for ($i = 1; $i <= $s_nato; $i++) {
		$s_npt[$i]=781;
		$s_r0[$i]=0.0001;
		$s_rmt[$i]=2.0;
		$s_zz[$i]="";
#		$umps = qx(echo  mult $s_mult[$i] >> $DIR/mist);
#                $s_mult[$i] = 1;
		if($s_mult[$i] < 1 ) { $s_mult[$i] = 1};
#		$umps = qx(echo  mult $s_mult[$i] >> $DIR/mist1);
		$s_isplit[$i] = 8;
	}
	&StructWrite;
	redirectURL("/util/structgen.pl?SID=$SID");
} else {
	$OUT .=  <<__STOP__;
<H2>StructGen<font size=-2><sup>TM</sup></font></H2>

<FORM ACTION="/util/structask.pl" METHOD=POST>
<INPUT TYPE=HIDDEN NAME="doit" VALUE=1>
__STOP__
	&PassHiddenParms;
        $ciffil=none;
	$OUT .=  <<__STOP__;
<h3>You do not have a $CASE.struct file yet. </h3>
<p class="info">
<b>You can create it using STRUCTGEN. Please specify the number of independent atoms of your  initial structure!</b>
<br><br>
Number of atoms: 
<INPUT NAME="numatoms" VALUE=2 SIZE=4>
<INPUT TYPE=SUBMIT VALUE="Generate template">
</p>

<p><hr>
<h3>Alternatively:</h3>
<table cellspacing="10">
<td valign="top"><b> Use cif2struct to convert a "cif" file: </b><br> 
(e.g. from the Inorganic crystal structure database)  
</p>
__STOP__

    # only show these lines if we have cif-files
    @ciffiles = qx(cd $DIR; /bin/ls -c *.cif);
    if (@ciffiles) {
	$OUT.="<p>Select one of the following \"cif\" files:<br>";
	foreach $i (@ciffiles) {
        $ii = $i;
	chop($ii);
	$OUT .=  <<__STOP__;
$i <INPUT TYPE=RADIO NAME="ciffil" VALUE="$ii" ><br>

__STOP__
}}
	$OUT .=  <<__STOP__;
</td>
<td valign="top"><b> to convert a "txt" file: </b> <br>
(for input definition see UG: cif2struct) </p>    

__STOP__
    @txtfiles = qx(cd $DIR; /bin/ls -c *.txt);
    if (@txtfiles) {
	$OUT.="<p>Select one of the following \"txt\" files:<br>";
	foreach $i (@txtfiles) {
        $ii = $i;
	chop($ii);
	$OUT .=  <<__STOP__;
$i <INPUT TYPE=RADIO NAME="txtfil" VALUE="$ii" ><br>


__STOP__
}}
$OUT.="</p></td></table><p><INPUT TYPE=SUBMIT VALUE=\"Use selected CIF/TXT file\">";
    
	$OUT .=  <<__STOP__;
</form>

<p> <hr>
<b> Use xyz2struct to convert a "xyz" file: </b> 
. 
</p>
<FORM ACTION="/util/xyz2struct.pl" METHOD=POST>
<INPUT TYPE=HIDDEN NAME="doit" VALUE=1>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
__STOP__

	&PassHiddenParms;
    # only show these lines if we have xyz-files
    @xyzfiles = qx(cd $DIR; /bin/ls -c *.xyz);
    if (@xyzfiles) {
	$OUT.="<p>Select one of the following \"xyz\" files:<br>";
	foreach $i (@xyzfiles) {
        $ii = $i;
	chop($ii);
	$OUT .=  <<__STOP__;
$i <INPUT TYPE=RADIO NAME="xyzfil" VALUE="$ii" ><br>
__STOP__
}
$OUT.="</p><p><INPUT TYPE=SUBMIT VALUE=\"Use selected XYZ file\">";
}
	$OUT .=  <<__STOP__;
 <hr><p>Here you can  <a href=\"/util/upload.pl?SID=$SID&cif=1\">$upload upload </a> a "cif" or "xyz" file from your local computer. 
</p>
</form>
__STOP__
	&PrintPage("Context",$OUT);
}
