#!/usr/bin/perl

require "../../libs/w2web.pl";

&GetInput;
&GetSession;

if ( -e "$DIR/$CASE.in0_grr" ) {
	redirectURL("/util/edit.pl?SID=$SID&file=$DIR/$CASE.in0_grr");
	# good, in0_grr file found.
} else {
	#$OUT .= "NO in0_grr file found" if $debug;
	$umps = qx( cd $DIR;cp $CASE.in0 $CASE.in0_grr);
	redirectURL("/util/edit.pl?SID=$SID&file=$DIR/$CASE.in0_grr");
	exit 0;
}
