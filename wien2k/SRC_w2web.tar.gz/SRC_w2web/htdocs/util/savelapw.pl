#!/usr/bin/perl

require "../../libs/w2web.pl";
$doit=0;

&GetInput;
&GetSession;

if (!$doit) {

$OUT = <<__STOP__;
<h3>save_lapw</h3>
By default save_lapw will delete the broyden files and save the <b>struct, clmsum, scf and necessary input files </b> with a name as specified below (specify eg. <b>case_rkm7_1000k_pbe_exp-vol</b>) in the current directory. <br>
<FORM ACTION="/util/savelapw.pl" METHOD=POST>
<INPUT TYPE=HIDDEN NAME="SID" VALUE="$SID">
<INPUT TYPE=HIDDEN NAME="doit" VALUE="1">
Save name or directory: 
$indent <INPUT NAME="savename"><br>
<br>
Alternatively you can also:<br>
<INPUT TYPE=CHECKBOX NAME=d> Save calculation in a directory as specified<br>
<INPUT TYPE=CHECKBOX NAME=m> Save only struct,clmsum,scf files (old scheme) <br>
<INPUT TYPE=CHECKBOX NAME=f> force save_lapw to overwrite previous saves<br>
<INPUT TYPE=CHECKBOX NAME=x> save the results of a DOS calculation only (int, qtl and dos* files, but no figures)<br>
<INPUT TYPE=CHECKBOX NAME=b> save the results of a band structure calculation only (insp, qtl, output1, outputso, klist_band, irrep and spaghetti* files, but no figures)<br>
<INPUT TYPE=CHECKBOX NAME=o> save the results of an optic calculation only (inop, injoint, inkram, klist/kgen/weight, symmat, joint, sigmak, refracti, epsilon, eloss absorp and sumrules* files, but no figures)<br>
<INPUT TYPE=CHECKBOX NAME=p> save the results of an eels calculation only (innes, elnes, broadspec, qtl files, but no figures)<br>
<INPUT TYPE=CHECKBOX NAME=q> save the results of an xspec calculation only (inix, xspec, corewfx, m1/m2, qtl and int files, but no figures)<br>
<br>
<INPUT TYPE=SUBMIT VALUE="save">
</FORM>

__STOP__

} else {
	$OUT .= "<h3>save_lapw $savename</h3>";

	if (!$savename) {
		$OUT .= "<b>ERROR</b> no save name given!";
	} else {
		$cmdline = "save_lapw";
		$cmdline .= " -o" if ($m);
		$cmdline .= " -f" if ($f);
		$cmdline .= " -d" if ($d);
		$cmdline .= " -dos" if ($x);
		$cmdline .= " -band" if ($b);
		$cmdline .= " -optic" if ($o);
		$cmdline .= " -eels" if ($p);
		$cmdline .= " -xspec" if ($q);
		$cmdline .= " $savename";

		$OUT .= "$cmdline";

		$out = qx(cd $DIR; $cmdline);
		$OUT .= "<pre>$out</pre>" ;
	}



}


PrintPage("save_lapw", $OUT);
