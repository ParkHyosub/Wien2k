#!/usr/bin/perl

require "../../libs/w2web.pl";

&GetInput;
&GetSession;

if ( -e "$DIR/$CASE.inm_vresp" ) {
	redirectURL("/util/edit.pl?SID=$SID&file=$DIR/$CASE.inm_vresp");
	# good, inm_vresp file found.
} else {
	#$OUT .= "NO inm_vresp file found" if $debug;
	$umps = qx( cd $DIR;cp $WIENROOT/SRC_templates/template.inm_vresp $CASE.inm_vresp);
	redirectURL("/util/edit.pl?SID=$SID&file=$DIR/$CASE.inm_vresp");
	exit 0;
}
