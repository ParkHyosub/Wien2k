#!/usr/bin/perl

require "../../libs/w2web.pl";
#$debug=1;

&GetInput;
&GetSession;
#$complex="CHECKED" if ( -e "$DIR/$CASE.in1c" );
&SaveSession;

$OUT .= "<h2>Initialization of Tran-Blaha mBJ calculations</h2> ";


$next="continue with mBJ - initialization";
$nexturl="/util/initmbj.pl?SID=$SID";
$nextinteractive=1;


        if( -e "$DIR/$CASE.inm_vresp"  && -s "$DIR/$CASE.inm_vresp" ) {
###### phase 2

$mytest="$DIR/$CASE.broyd1";
    if ( -e $mytest ) {
$OUT .= <<__STOP__;
<H2>Broyden files exist from previous scf-cycle!</H2>
<p>
<p> Do you want to
</p>
<ul>
<li><A HREF="/util/savelapw.pl?SID=$SID">Save Calculation with save_lapw</A>
</ul>
<ul>
<li><A HREF="/util/delete.pl?SID=$SID&file=$DIR/$CASE.broyd*">Remove the
files $CASE.broyd[1|2] </A>
</ul>
__STOP__
    } else {

$umps=qx(sed "1s/TOT....../TOT   28 /" $DIR/$CASE.in0_tmp > $DIR/$CASE.in0);
$umps=qx(sed "1s/TOT....../TOT   50 /" $DIR/$CASE.in0_tmp > $DIR/$CASE.in0_grr);
$OUT.="<br><h2>We are in phase 2 out of 2 steps </h2>";
$OUT.=" prepared $file.in0_grr and changed to 28 in $file.in0<br>";
$OUT.="  Now do the mBJ calculation: <br><br>  <b>run_lapw -i 80 ...</b>  ";

    }

	} else {
##### phase 1
$umps=qx(cp $WIENROOT/SRC_templates/template.inm_vresp $DIR/$CASE.inm_vresp );
$umps=qx(sed "2s/NR2V/R2V/" $DIR/$CASE.in0 >$DIR/$CASE.in0_tmp; cp $DIR/$CASE.in0_tmp $DIR/$CASE.in0);

$OUT.=<<__STOP__;
<br><h2>We are in phase 1 out of 2 steps </h2>
prepared $CASE.inm_vresp and set R2V in $CASE.in0 <br>
Now do: <br> <br>  
<b>run_lapw -i 1 -NI</b>  &nbsp;&nbsp;&nbsp;  #   to prepare the r2v and vresp files with ONE iteration<br>
<b>save_lapw -d pbe </B>  &nbsp;&nbsp;  #   save the pbe run <br>
<b>init_mbj_lapw  </B>    &nbsp;&nbsp;&nbsp;&nbsp;  #   rerun the init script to finish mbj-initialization<br>
__STOP__

        }

PrintPage("Context",$OUT);

