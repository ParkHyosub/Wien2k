#!/usr/bin/perl

require "../../libs/w2web.pl";
#$debug=1;

&GetInput;
&GetSession;
#$complex="CHECKED" if ( -e "$DIR/$CASE.in1c" );
&SaveSession;

$OUT .= "<h2>Initialization of full-hybrid calculations</h2> ";


$next="continue with full-hybrid initialization";
$nexturl="/util/inithf.pl?SID=$SID";
$nextinteractive=1;

#&InitTask();
	$filec="";
	if($complex =~ /CHECKED/ ) {
		$mycomplex="-c";
		$filec="c";
	} else {
#        $dum = qx(cp $DIR/$CASE.in2 $DIR/$CASE.in2c) if(! -s "$DIR/$CASE.in2c");
#        $OUT .= "<p> $CASE.in2c has been created" if(! -s "$DIR/$CASE.in2c"); 
    }

$OUT .=  qx(cd $DIR/;init_hf_lapw -s );

#&RequiredFile("inhf");
#&RequiredFile("in0_grr_hf");
#$dum = qx(cp $DIR/$CASE.in0_grr_hf $DIR/$CASE.in0_grr);
#$dum = qx(sed "1s/TOT....../TOT   13 /" $DIR/$CASE.in0 >$DIR/$CASE.in0_tmp);
#$dum = qx(mv $DIR/$CASE.in0_tmp $DIR/$CASE.in0);

$OUT .="<pre>";
$OUT .= qx(head -30 $DIR/$CASE.scf2up) if($spinpol=~ /CHECKED/ );
$OUT .= qx(head -30 $DIR/$CASE.scf2) ;
$OUT .="</pre>";

$OUT.="<TABLE BGCOLOR=$green>";

$OUT.=<<__STOP__;
</TD></TR>
<TR><TD BGCOLOR=$gray>
<FORM ACTION="/util/edit.pl">
<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT NAME=file VALUE="$DIR/$CASE.inhf" TYPE=HIDDEN>
<INPUT NAME=redir VALUE="/util/inithf.pl?SID=$SID" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="edit $CASE.inhf">
You must set <b>NBAND</b> to at least  <b>NB_occ + 1</b>
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>

<TR><TD BGCOLOR=$gray>
<FORM ACTION="/util/edit.pl">
<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT NAME=file VALUE="$DIR/$CASE.in1$filec" TYPE=HIDDEN>
<INPUT NAME=redir VALUE="/util/inithf.pl?SID=$SID" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="edit $CASE.in1$filec">
set larger EMAX in $CASE.in1 (only in case you want NBAND > available bands) 
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>
__STOP__

$OUT.=<<__STOP__;
<TR><TD BGCOLOR=$gray>
Prepare k-mesh for HF. 
You may want to use a (commensurate) REDUCED k-mesh for the HF-potential to save cpu-time. <br>
<FORM ACTION="/util/run_kgenhf.pl">
<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT NAME=redir VALUE="/util/inithf.pl?SID=$SID" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="run_kgenhf_lapw">&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;
 with k-mesh (eg. 4x4x4):&nbsp; 
nx=$nx <INPUT size=3 NAME="nx"> ny=$ny <INPUT size=3 NAME="ny"> nz=$nz <INPUT size=3 NAME="nz"><br>
&nbsp;&nbsp;&nbsp; &nbsp; with commensurate reduced k-mesh (eg. 2x2x2):&nbsp; 
nx=$nrx <INPUT size=3 NAME="nrx"> ny=$nry <INPUT size=3 NAME="nry"> nz=$nrz <INPUT size=3 NAME="nrz">  <br>
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>

__STOP__

$OUT.="</TABLE>";
$OUT.=<<__STOP__;
Once the steps above are done, do the hybrid calculation with:  <br>
<b> run_lapw -hf [-redklist] ...</b>  (-redklist when you selected a reduced k-mesh above) 
__STOP__

PrintPage("Context",$OUT);

