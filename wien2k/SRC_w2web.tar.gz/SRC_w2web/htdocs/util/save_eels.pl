#!/usr/bin/perl

require "../../libs/w2web.pl";
$doit=0;

&GetInput;
&GetSession;

if (!$doit) {

$OUT = <<__STOP__;
<h3>save_lapw -eels</h3>

<FORM ACTION="/util/save_eels.pl" METHOD=POST>
	<INPUT TYPE=HIDDEN NAME=nexturl VALUE="$nexturl">
	<INPUT TYPE=HIDDEN NAME=next VALUE="$next">
<INPUT TYPE=HIDDEN NAME="SID" VALUE="$SID">
<INPUT TYPE=HIDDEN NAME="doit" VALUE="1">
<INPUT TYPE=CHECKBOX NAME=d> Save into directory<br>
<INPUT TYPE=CHECKBOX NAME=f> force save_eels to overwrite previous saves<br>

<br>
Save_name or save_directory:
 <INPUT NAME="savename" VALUE='eels'> <br>
<br>
<INPUT TYPE=SUBMIT VALUE="save">
</FORM>

__STOP__

} else {
#	$OUT .= "<h3>save_eels $savename</h3>";

	if (!$savename) {
		$OUT .= "<b>ERROR</b> no save name given!";
	} else {
		$cmdline = "save_lapw -eels";
	#	$cmdline .= " -a" if ($a);
		$cmdline .= " -f" if ($f);
		$cmdline .= " -d" if ($d);
		$cmdline .= " $savename";

		$OUT .= "<h3>$cmdline </h3>";

		$out = qx(cd $DIR; $cmdline);
		$OUT .= "<pre>$out</pre>" ;
	}

		$OUT .= <<__STOP__;
<FORM ACTION="/exec/next.pl">
<INPUT TYPE=HIDDEN NAME=nexturl VALUE="$nexturl">
<INPUT TYPE=submit VALUE="$FORM{'next'}">
</FORM>
__STOP__



}


PrintPage("save_eels", $OUT);
