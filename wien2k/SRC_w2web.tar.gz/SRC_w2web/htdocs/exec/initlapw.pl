#!/usr/bin/perl

require "../../libs/w2web.pl";
$phase=0;
$doinst=0;
$endphase=0;
$instgenlog=0;
#$complex="";
#$c="";
#$spinpol="";
$spin="up";
&GetInput;
&GetSession;
&SaveSession;
$restart_init = "";
$addtext="";
$endtext="";
$nextinteractive=1;

$OUT .= "<h2>Initialize calculation </h2>";

#if(defined($doit) && $doit==20)
#{
    $OUT .= "<h3>Fast mode:</h3>";
    $OUT .= &ExpertOption();
#    $OUT .= "</table>";
#}

#if(!defined($doit) || $doit!=20)
#{
#    $OUT .= "<br><br><h3>Fast mode:</h3><table>";
#    $OUT .= &ExpertOption();
#    $OUT .= "</table>";
#}

if (!$phase) {
    $OUT .= "Phase not found" if ($debug);
    if ( -e "$DIR/.initphase" ) {
	$oldphase = qx(cat $DIR/.initphase);
	$tmp = $oldphase -1;
	$restart_init .= "<FORM ACTION=/exec/initlapw.pl><INPUT TYPE=HIDDEN NAME=SID VALUE=$SID><INPUT TYPE=HIDDEN NAME=phase VALUE=$tmp><INPUT TYPE=SUBMIT VALUE=\"Restart with phase $oldphase?\"></FORM>";
    }
}

$inactivecolor=$gray;

if ($phase == 20 || $phase == 24  ) {
    $inactivecolor=$gray;
    $endtext="<h2>Initialization done</h2><p class=\"info\"><A HREF=/exec/scf.pl?SID=$SID>Continue with run SCF</A></p>";
#    $complex="CHECKED" if ( -e "$DIR/$CASE.in1c" );
    &SaveSession;
}

if ($phase == 20)
{
    &SaveSession;
    &GetSession;
#    my $compl=(-f "$DIR/$CASE.in1c")?"c":"";
    chomp(my $a=`grep K-VECTORS $DIR/$CASE.in1_st|grep -v red|head -1`);
    if($a=~/[0-9]+\s+[-.0-9]+\s+[-.0-9]+\s+([0-9]+)/)
    {
	my $aa=$1;
	my $a2=int($aa/2);
	`sed "s/ $aa / $a2 /" $DIR/$CASE.in1_st > $DIR/.tmp`;
	`sed -e "s^\\(K-VECTORS.\\{1,\\}\\)^\\1 #red^" $DIR/.tmp > $DIR/$CASE.in1_st`;
	`rm $DIR/.tmp`;
	`cp $DIR/$CASE.in1_st $DIR/$CASE.in1$filec`;
    }
    else
    {
	#do nothing
    }
}

sub mark {
    $bgcolor="taskactive";
}
sub reset {
    $bgcolor="task";
    $nextinteractive=1;
}

&reset;

sub Execute {
    $next    = "initlapw";
    $ia = "";
    if ($interactive) {
	$ia="<INPUT TYPE=checkbox NAME=nextinteractive CHECKED ><small>interactively</small>"
	} else {
	    $ia="<INPUT TYPE=hidden NAME=nextinteractive VALUE=1>"
	    }
    $nexturl = "/exec/initlapw.pl?SID=$SID&phase=$myphase";
    $OUT .=  <<__STOP__;
<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__
&PassHiddenParms;
    $OUT .=  <<__STOP__;
<TR><TD class="$bgcolor">
<INPUT TYPE=HIDDEN NAME=precmd VALUE="$precmd">
<INPUT TYPE=hidden NAME=prog VALUE=$prog>
<INPUT TYPE=hidden NAME=c VALUE=$c>
<INPUT TYPE=hidden NAME=spinpol VALUE=$spinpol>
<INPUT TYPE=hidden NAME=spin VALUE=$spin>
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
<INPUT TYPE=SUBMIT VALUE="$title" >
$ia</FORM><small>$addtext</small></TD></TR>
__STOP__
     $addtest="";
    &reset;
}

sub Edit {
    $next = "initlapw";
    $dum=$myphase;
    if ($endphase > 0) {
	$dum = $endphase;
    }
    $nexturl = "/exec/initlapw.pl?SID=$SID&phase=$dum";
    $OUT .=  <<__STOP__;
<FORM ACTION=/util/edit.pl METHOD=POST>
<TR><TD class="$bgcolor">
__STOP__
    &PassHiddenParms;
    $OUT .=  <<__STOP__;
<INPUT TYPE=hidden NAME=file VALUE="$file">
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
<INPUT TYPE=SUBMIT VALUE="$title" >
</FORM><small>$addtext</small></TD></TR>
__STOP__
    $addtext="";
    &reset;
}

$phase++;
$OUT .=  <<__STOP__;
<h3>Individual mode <small>(phase $phase)</small></h3>
For <b>antiferromagnets, self-generated structures, supercells and surfaces</b> we recommend to run at least the first steps (until instgen) manually and accept the recommendations of the symmetry programs.
$restart_init
<table border=0 cellspacing=0 cellpadding=1 class="$bgcolor"><tr valign=top><td>
<table cellpadding=1 cellspacing=2>
__STOP__

$myphase = 1;
&mark if ($phase == $myphase);
$title = "x nn";
$precmd  = "x";
$prog    = "nn";
$next    = "initlapw";
&Execute();



$myphase = 2;
&mark if ($phase == $myphase);
$title = "view outputnn";
$file    = "$DIR/$CASE.outputnn";
&Edit();
$bb = qx(grep UNPHYSICAL $DIR/$CASE.outputnn | wc -l );
if ($bb > 0 && $phase == $myphase) {
	&mark if ($phase == $myphase);
	$title = "choose";
	$OUT .= "<tr><td class=\"$bgcolor\">";
		$OUT .= <<__STOP__;
<b>ERROR: Your sphere sizes are unphysically small !!!!
<br> 
       Most likely your structure is WRONG and will lead to a crash later.
       You should probably stop and recheck your struct file 
__STOP__
}
$bb = qx(grep FATAL $DIR/$CASE.outputnn | wc -l );
if ($bb > 0 && $phase == $myphase) {
	&mark if ($phase == $myphase);
	$title = "choose";
	$OUT .= "<tr><td class=\"$bgcolor\">";
		$OUT .= <<__STOP__;
<b>ERROR: Your atoms sit at identical positions !!!!
<br> 
       Your structure is WRONG. Stop and recheck your struct file. 
__STOP__
}

$myphase = 3;
$bb = qx(grep WARNING $DIR/$CASE.outputnn | wc -l );
if ($bb > 0 && $phase == $myphase) {
	&mark if ($phase == $myphase);
	$title = "choose";
	$OUT .= "<tr><td class=\"$bgcolor\">";
	if ($doit==1) {
		$dum = qx(cp $DIR/$CASE.struct $DIR/$CASE.struct_init);
		$dum = qx(cp $DIR/$CASE.struct_nn $DIR/$CASE.struct);
		$dum = qx(cd $DIR; echo y | instgen);
		$OUT .= <<__STOP__;
<b>$CASE.struct_nn copied to $CASE.struct<br> 
   old struct-file saved as $CASE.struct_init<br>
   $CASE.inst updated</b>
<br>
<FORM ACTION=/util/structgen.pl>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=SUBMIT VALUE="Start StructGen ?">
</FORM>
__STOP__
	} else {
		$OUT .= <<__STOP__;
Use new struct-file? 
<ul>
<FORM ACTION=/exec/initlapw.pl>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=HIDDEN NAME=phase VALUE=2>
<INPUT TYPE=HIDDEN NAME=doit VALUE=1>
<INPUT TYPE=SUBMIT VALUE="Yes">
</FORM>
<FORM ACTION=/exec/initlapw.pl>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=HIDDEN NAME=phase VALUE=$myphase>
<INPUT TYPE=SUBMIT VALUE="No">
</FORM>
</UL>
__STOP__
	}
	$OUT .= "</td></tr>";
	&reset;
}


$myphase = 4;
&mark if ($phase == $myphase);
&mark if ($phase == 3 && $bb == 0);
$title = "x sgroup";
$precmd  = "x";
$prog    = "sgroup";
$next    = "initlapw";
&Execute();

$myphase=5;
&mark if ($phase == $myphase);
$title = "view outputsgroup";
$file    = "$DIR/$CASE.outputsgroup";
$sg1 = qx(grep '\!\!' $DIR/$CASE.outputsgroup  );
$sg = qx(grep 'space group' $DIR/$CASE.outputsgroup | grep -v NOTE );
$sg =~ s/.*://;
$addtext="$sg1<br>sgroup found: $sg" if ($phase == $myphase || $phase == 6);
&Edit();

$myphase = 6;
if ($phase == $myphase) {
$docopy=$myphase-1;
&mark if ($phase == $myphase);
$title = "choose";
if ($doit==1) {
	$OUT .= "<tr><td class=\"taskoption\">";
	$dum = qx(cp $DIR/$CASE.struct $DIR/$CASE.struct_init);
	$dum = qx(cp $DIR/$CASE.struct_sgroup $DIR/$CASE.struct );
	$dum = qx(cd $DIR; echo y | instgen);

	$OUT .= <<__STOP__;
<b>$CASE.struct_nn copied to $CASE.struct<br> 
   old struct-file saved as $CASE.struct_init<br>
   $CASE.inst updated</b>
<br>
<FORM ACTION=/util/structgen.pl>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=SUBMIT VALUE="Start StructGen ?"> optional
</FORM>
__STOP__
	$phase++;
	} else {
		$OUT .= <<__STOP__;
<tr><td class="$bgcolor">
Use struct-file generated by sgroup? (Usually NO, unless WARNINGS appeared above) 
<ul>
<FORM ACTION=/exec/initlapw.pl>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=HIDDEN NAME=phase VALUE=$docopy>
<INPUT TYPE=HIDDEN NAME=doit VALUE=1>
<INPUT TYPE=SUBMIT VALUE="Yes">
</FORM>
<FORM ACTION=/exec/initlapw.pl>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=HIDDEN NAME=phase VALUE=$myphase>
<INPUT TYPE=SUBMIT VALUE="No">
</FORM>
</UL>
__STOP__
}
$OUT .= "</td></tr>";
&reset;
}

$myphase = 7;
&mark if ($phase == $myphase);
$title = "x symmetry";
$precmd  = "x";
$prog    = "symmetry";
$next    = "initlapw";
&Execute();

$myphase = 8;
&mark if ($phase == $myphase);
$title = "copy struct_st";
$addtext = "and view outputs";
$file    = "$DIR/$CASE.outputs";
&Edit();

$myphase = 9;
$bb = qx(grep SHIFTED $DIR/$CASE.outputs | wc -w );
if ($bb == 9) {
  &mark if ($phase == $myphase);
  $title = "choose";
  $OUT .= <<__STOP__;
<tr><td class="$bgcolor">
<b>Warning!</b><br>
You must move the origin 
<br>
(see file $CASE.outputs)
<FORM ACTION=/util/structgen.pl>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=SUBMIT VALUE="Start StructGen ?">
</FORM>
__STOP__
	$OUT .= "</td></tr>";
	&reset;
}

$myphase = 10;
if ($phase == $myphase || ($phase == 9 && $bb!=9) ) {
#    &mark;
    $umps = qx(cp $DIR/$CASE.struct_st  $DIR/$CASE.struct);
}

    $file="$DIR/$CASE.inst";
    if (-e $file && -s $file && $instgenlog!=1) {
	#good there is an inst file

#	$OUT .= "$CASE.inst exists, run instgen_lapw only for non-default spin-configuration!<br>\n ";
$title = "instgen_lapw";
$precmd  = "";
$addtext = "$CASE.inst exists, run instgen_lapw only for non-default spin-configuration";
$prog    = "instgen_lapw";
$next    = "initlapw";
$myphase--;
&Execute();
&mark if ($phase == $myphase || ($phase == 10));
$title = "x lstart";
$precmd  = "x";
$addtext = "";
$prog    = "lstart";
$next    = "initlapw";
$myphase++;
&Execute();
	} else {
&mark if ($phase == 9);
#	$OUT .= "$CASE.inst needs to be generated by instgen_lapw!<br>\n ";
$title = "instgen_lapw";
$precmd  = "";
$addtext = "$CASE.inst needs to be generated by  instgen_lapw";
$prog    = "instgen_lapw";
$next    = "initlapw";
$myphase--;
&Execute();
        }


$myphase=11;
if ($phase ==$myphase ) {

$bb = qx(grep WARNING $DIR/$CASE.outputst | wc -w);
if ($bb > 2 || $doinst) {
	&mark if ($phase == $myphase);
	$title = "edit inst";
	$file    = "$DIR/$CASE.inst";
	if($doinst) {
		$bb=3; # to cheat next if statemend :-)
	} else {
		$addtext=qx(grep WARNING $DIR/$CASE.outputst);
                $addtext.="<br>Check $CASE.outputst for which atom/states the core-leakage occurs and rerun lstart with lower core-seperation energy (or increase RMT)";
	}
	$endphase=9 if ($phase == $myphase);
#	&Edit();
}

        &mark;
        $umps=qx(cd $DIR; cat $CASE.in2_ls $CASE.in2_sy > $CASE.in2_st);
}
#&mark if ($phase == $myphase);
$title = "view outputst";
$addtext = "";
$file    = "$DIR/$CASE.outputst";
&Edit();

$OUT .= "</table></td><td><table cellpadding=1 cellspacing=0>";

$myphase=12;
$bb = qx(grep IZ $DIR/$CASE.outputst | wc -w);
if ($bb > 2 || $doinst) {
	&mark if ($phase == $myphase);
	$title = "edit inst";
	$file    = "$DIR/$CASE.inst";
	if($doinst) {
		$bb=3; # to cheat next if statemend :-)
	} else {
		$addtext="error: $CASE.inst not consistent with Z<br>edit $CASE.inst and rerun lstart afterwards or change Z in StructGen!";
	}
	$endphase=9 if ($phase == $myphase);
	&Edit();
	$OUT.=<<__STOP__;
<tr><td class="$bgcolor">
<FORM ACTION=/util/structgen.pl>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=SUBMIT VALUE="Start StructGen ?">
</FORM>
</td></tr>
__STOP__
}



$myphase = 13;
&mark if ($phase == $myphase);
&mark if ($phase == 12 && $bb <= 2);
$title = "check $CASE.in1_st";
$addtext='set RKmax (usually 5.0-9.0). <A HREF="http://www.wien2k.at/reg_user/faq/rkmax.html" TARGET=rkmax>Click here for more info</A>';
$file    = "$DIR/$CASE.in1_st";
&Edit();

$myphase = 14;
if ($phase ==$myphase ) {
	&mark;
#	$umps=qx(cd $DIR; cat $CASE.in2_ls $CASE.in2_sy > $CASE.in2_st);
}
$title = "check $CASE.in2_st";
$file    = "$DIR/$CASE.in2_st";
$addtext="set Fermi-method and GMAX";
&Edit();


#$myphase = 15;
#&mark if ($phase == $myphase);
#$title = "check $CASE.inm_st";
#$file    = "$DIR/$CASE.inm_st";
#$addtext="Reduce mixing for localized magnetic systems";
#&Edit();


$myphase = 15;
&mark if ($phase == $myphase);
$OUT .= "<tr><td class=\"$bgcolor\">";
$tmp=$myphase+1;
if ($doit==1 && $phase == $tmp) {
	$myphase++;
	$dum = qx(cp $DIR/$CASE.in0_st $DIR/$CASE.in0);
	$dum = qx(cp $DIR/$CASE.in1_st $DIR/$CASE.in1);
	$dum = qx(cp $DIR/$CASE.in2_st $DIR/$CASE.in2);
	$dum = qx(cp $DIR/$CASE.inc_st $DIR/$CASE.inc);
	$dum = qx(cp $DIR/$CASE.inm_st $DIR/$CASE.inm);
	$dum = qx(cp $DIR/$CASE.inq_st $DIR/$CASE.inq);
	$mout .= "in0, in1, in2, inc and inm files generated";

        &SaveSession;
#	$bb = qx(grep INVERSION $DIR/$CASE.outputs | wc -w);
#	if ($bb == 7) {
	if ($complex =~ /CHECKED/ ) {
		# no inversion symmetry
		$dum = qx(mv $DIR/$CASE.in1 $DIR/$CASE.in1c);
		$dum = qx(mv $DIR/$CASE.in2 $DIR/$CASE.in2c);
		$mout .= "in0, in1c, in2c, inc and inm files generated";
	}
	$OUT .= $mout;
} else {
	$OUT .= <<__STOP__;
<FORM ACTION=/exec/initlapw.pl>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=HIDDEN NAME=phase VALUE=$myphase>
<INPUT TYPE=HIDDEN NAME=doit VALUE=1>
<INPUT TYPE=SUBMIT VALUE="Prepare input files" >
</FORM>
__STOP__
}
&reset;

$myphase = 16;
&mark if ($phase == $myphase);
$title = "x kgen";
$precmd  = "x";
$prog    = "kgen";
$next    = "initlapw";
&Execute();


$myphase=17;
&mark if ($phase == $myphase);
$title = "view klist";
$file    = "$DIR/$CASE.klist";
&Edit();

$myphase = 18;
&mark if ($phase == $myphase);
#if ( -e "$DIR/$CASE.in1c" ) {
#	$c="on";
#	$addtext="<br>complex selected";
#}
$spinpol="";
$spin="";
$title = "x dstart";
$precmd  = "x";
$prog    = "dstart";
$interactive = 1;
$next    = "initlapw";
&Execute();


$OUT .= "</table></td><td><table cellpadding=1 cellspacing=0>";

$myphase=19;
&mark if ($phase == $myphase); 
$title = "view $CASE.outputd and cp $CASE.in0_std $CASE.in0";
$addtext = "check if gmax>gmin";
$file    = "$DIR/$CASE.outputd";
&Edit();


$myphase=20;

if ($phase < 21) {
    if ($phase == $myphase) {
	&mark;
$dum = qx(cp $DIR/$CASE.in0_std $DIR/$CASE.in0);
$dum = qx(cp $DIR/$CASE.clmsum $DIR/new_super.clmsum);
}
$title = "choose";
$OUT .= <<__STOP__;
<tr><td class="$bgcolor">
Perform spin-polarized calc.?
<ul>
<FORM ACTION=/exec/initlapw.pl>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=HIDDEN NAME=phase VALUE=20>
<INPUT TYPE=SUBMIT VALUE="No" >
</FORM>
<FORM ACTION=/exec/initlapw.pl>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=HIDDEN NAME=phase VALUE=21>
<INPUT TYPE=SUBMIT VALUE="Yes" >
</FORM>
</UL>
__STOP__
$OUT .= "</td></tr>";
&reset;
}


$myphase=21; 
if ($phase==$myphase) {
	$spinpol="";
	&SaveSession;
#	$prefspace="single";
#	&SavePrefs();
#	$prefspace="scf";
#	&SavePrefs();
}
# dummy for "we are done" if non-sp calc.
#


# ------ spin polarized ---

if ($phase > 21) {
$myphase = 22;
&mark if ($phase == $myphase);
#if ( -e "$DIR/$CASE.in1c" ) {
#  $c="on";
#  $addtext="<br>complex selected";
#}

$spinpol="on";
&SaveSession;
# bloody SaveSession corrupts my $spinpol
# easy way out: just set it again to "on" *ggggg
#
#$prefspace="single";
#SavePrefs();
#$prefspace="scf";
#SavePrefs();

$spinpol="on";
$spin="up";
$title = "x dstart -$spin";
$precmd  = "x";
$prog    = "dstart -up";
$interactive = 1;
$next    = "initlapw";
&Execute();
&reset;

$myphase = 23;
&mark if ($phase == $myphase);
#if ( -e "$DIR/$CASE.in1c" ) {
#  $c="on";
#  $addtext="<br>complex selected";
#}
$spinpol="on";
$spin="dn";
$title = "x dstart -$spin";
$precmd  = "x";
$prog    = "dstart";
$interactive = 1;
$next    = "initlapw";
&Execute();
&reset;

$myphase=24;
if ($phase == $myphase){
$dum = qx(cp $DIR/$CASE.clmup $DIR/new_super.clmup);
$dum = qx(cp $DIR/$CASE.clmdn $DIR/new_super.clmdn);
&mark 
}
$title = "choose";
$OUT .= <<__STOP__;
<tr><td class="$bgcolor">
Perform antiferromagnetic calc.? 
<ul>
<FORM ACTION=/exec/initlapw.pl>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=HIDDEN NAME=phase VALUE=25>
<INPUT TYPE=SUBMIT VALUE="Yes">
</FORM>
<FORM ACTION=/exec/initlapw.pl>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=HIDDEN NAME=phase VALUE=24>
<INPUT TYPE=SUBMIT VALUE="No">
</FORM>
</UL>
__STOP__
$OUT .= "</td></tr>";
&reset;


$myphase=25;
#$afm="";
#&SaveSession;
#$prefspace="scf";
#&SavePrefs();
#$afm="";
# dummy: no afm calc

if ($phase > $myphase) {

$myphase=26;
if ($phase == $myphase) {
&mark if ($phase == $myphase);
#$afm="on";
#&SaveSession;
#$prefspace="scf";
#&SavePrefs();
#$afm="on";
$title = "choose";
$OUT .= <<__STOP__;
<tr><td class="$bgcolor">
<p>
<ul>
Did you define the desired magnetic order in <b>instgen_lapw</b> ?<br>
Did you flip the spin on the AFM-atoms and select no spin on non-magentic atoms <br> 
(eg. O in NiO) in $CASE.inst?<br>
If not:
<FORM ACTION=/exec/initlapw.pl>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=HIDDEN NAME=phase VALUE=9>
<INPUT TYPE=HIDDEN NAME=doinst VALUE=1>
<INPUT TYPE=HIDDEN NAME=instgenlog VALUE=1>
<INPUT TYPE=SUBMIT VALUE="edit $CASE.inst">
</FORM>
You can run AFM cases as regular spin-polarized cases (runsp_lapw), 
but experienced users can setup an AFM case when one specifies a 
symmetry operation which transforms equivalent spin-up and spin-dn atoms 
into each other. In certain cases, this can be done automatically when
you have a $CASE.struct_supergroup file from the nonmagnetic case (see UG).
<FORM ACTION=/exec/initlapw.pl>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=HIDDEN NAME=phase VALUE=26>
<INPUT TYPE=SUBMIT VALUE="Yes, continue with afminput">
</FORM>
<FORM ACTION=/exec/scf.pl>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=HIDDEN NAME=afm VALUE="off">
<INPUT TYPE=SUBMIT VALUE="No, continue with scf">
</FORM>
</UL>
__STOP__
$OUT .= "</td></tr>";
&reset;
}


$myphase = 27;
&mark if ($phase == $myphase);
$title = "x afminput";
$precmd  = "x";
$prog    = "afminput";
$next    = "initlapw"; 
&Execute();
&reset;


$myphase = 28;
$afm="on" if ($phase == $myphase);
&SaveSession;
&mark if ($phase == $myphase);
$title = "view outputafminput";
$file    = "$DIR/$CASE.outputafminput";
&Edit();
&reset;

$myphase = 29;
&mark if ($phase == $myphase);
$title = "view inclmcopy_st";
$file    = "$DIR/$CASE.inclmcopy_st";
&Edit();
&reset;

$myphase=30;
if($phase==$myphase) {
    &mark;
    if ($doit==1) {
	$dum = qx(cp $DIR/$CASE.inclmcopy_st $DIR/$CASE.inclmcopy);
	$OUT .= "<tr><td class=\"$bgcolor\">inclmcopy created</td></tr>";
	$endtext="<h2>Initialization done</h2><p class=\"info\">Continue with <A HREF=/exec/scf.pl?SID=$SID&spinpol=$spinpol>run SCF</A></p>";
    } else {
	$OUT .= <<__STOP__;
<tr><td class="$bgcolor">
<FORM ACTION=/exec/initlapw.pl>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=HIDDEN NAME=phase VALUE=29>
<INPUT TYPE=HIDDEN NAME=doit VALUE=1>
<INPUT TYPE=SUBMIT VALUE="copy inclmcopy_st">
</FORM>
</td></tr>
__STOP__
}
}
}
}

#
#  ------------------------------------------
#  
$OUT .= "</table>";
$OUT .= "</td></tr></table>";
$OUT .= $endtext;

if ($endphase >0) {
    $phase = $endphase;
}
system "echo $phase >$DIR/.initphase";

PrintPage("init_lapw",$OUT);


#Buaaaah ... What the hell of a dirty and unreadable code!!!!

sub ExpertOption
{
    &GetSession();
    my @in=("expert_red","expert_vxc","expert_ecut","expert_rkmax","expert_fermit","expert_mix","expert_numk");
    my @sess=("SESSION_EXPERT_RED","SESSION_EXPERT_VXC","SESSION_EXPERT_ECUT","SESSION_EXPERT_RKMAX","SESSION_EXPERT_FERMIT","SESSION_EXPERT_MIX","SESSION_EXPERT_NUMK");
    my $errtext="";
    my $err=0;
    my $disabled="";
    for(my $i=0;$i<@in;$i++)
    {
	my $userin=$in[$i];
	my $sessionvar=$sess[$i];
	if(!defined($$userin))
	{
	    if(defined($$sessionvar))
	    {
		$$userin=$$sessionvar;
	    }
	    else
	    {
		$$userin="";
	    }
	}
    }
    #spinpol is different .. sigh
    if($doit!=20 && ($spinpol=~/on/i || $spinpol=~/checked/i))
    {
	$expert_spinpol=1;
    }
    my $arguments="-b ";
    if($expert_vxc=~/.+/)
    {
	if($expert_vxc!~/^(13|5|11|19)$/)
	{
	    $errtext.="VXC must be a number, either 13, 5, 11 or 19 (or leave it blank)<br>";
	}
	else
	{
	    $arguments.="-vxc $expert_vxc ";
	}
    }
    if($expert_red=~/.+/)
    {
	if($expert_red!~/^[0-9]{1,2}\.?[0-9]*$/)
	{
	    $errtext.="RMT reduction must be a floating point number<br>";
	}
	else
	{
	    $arguments.="-red $expert_red ";
	}
    }
    if($expert_ecut=~/.+/)
    {
	if($expert_ecut!~/^-[0-9]{1,2}\.?[0-9]*$/)
	{
	    $errtext.="ECUT reduction must be a negative floating point number<br>";
	}
	else
	{
	    $arguments.="-ecut $expert_ecut ";
	}
    }
    if($expert_rkmax=~/.+/)
    {
	if($expert_rkmax!~/^[0-9]{1,2}\.?[0-9]*$/ )
	{
	    $errtext.="RKMAX reduction must be a floating point number<br>";
	}
	elsif($expert_rkmax <= "2")
	{
	    $errtext.="RKMAX must be between 2.0 and 11.0<br>";
	}
	elsif($expert_rkmax >= "11")
	{
	    $errtext.="RKMAX must be between 2.0 and 11.0<br>";
	}
	else 
	{
	    $arguments.="-rkmax $expert_rkmax ";
	}
    }
    if($expert_fermit=~/.+/)
    {
	if($expert_fermit!~/^[0-9]{1,2}\.?[0-9]*$/)
	{
	    $errtext.="FERMIT reduction must be a floating point number<br>";
	}
	elsif($expert_fermit >= "0.0201")
	{
	    $errtext.="FERMIT must be below 0.02<br>";
	}
	else
	{
	    $arguments.="-fermit $expert_fermit ";
	}
    }
#    if($expert_mix=~/.+/)
#    {
#	if($expert_mix!~/^[0-9]{1,2}\.?[0-9]*$/)
#	{
#	    $errtext.="MIX reduction must be a floating point number<br>";
#	}
#	else
#	{
#	    $arguments.="-mix $expert_mix ";
#	}
#   }
    if($expert_numk=~/.+/)
    {
	if($expert_numk!~/^[0-9]+$/)
	{
	    $errtext.="Number of k-points (NUMK) must be an integer<br>";
	}
	else
	{
	    $arguments.="-numk $expert_numk ";
	}
    }
    if($expert_spinpol)
    {
	$arguments.="-sp ";
	$spinpol="on";
    }
    my $text="";
    $text.="<tr><td width=100% colspan=3>";
    if(defined($doit) && $errtext!~/.+/)
    {
	$text.="<FORM ACTION=/exec/executor.pl METHOD=POST>";
#        $text.="cd $DIR;$prog $arguments >$DIR/STDOUT 2>&1 &";
#        system "cd $DIR;$prog $arguments >$DIR/STDOUT 2>&1";
#        $text.="<A HREF='/util/stdout.pl?SID=$SID'>View STDOUT</A> to monitor the progress of this command"
    }
    else
    {
	$text.="<FORM ACTION=/exec/initlapw.pl METHOD=POST>";
    }
    if($errtext=~/.+/)
    {
	$err=1;
    }
    elsif($doit==20)
    {
	$disabled="disabled";
    }
    $text.=&GetHiddenParms();
    $text.="<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>";
    $text.="<INPUT TYPE=HIDDEN NAME=phase VALUE=0>";
    $text.="<INPUT TYPE=HIDDEN NAME=doit VALUE=20>";
    $text.="<INPUT TYPE=HIDDEN NAME=precmd VALUE=''>";
    $text.="<INPUT TYPE=HIDDEN NAME=spinpol VALUE='$spinpol'>";
    $text.="<INPUT TYPE=hidden NAME=prog VALUE='init_lapw $arguments'>";
    $text.="<INPUT TYPE=hidden NAME=nexturl VALUE='/exec/initlapw.pl?SID=$SID&doit=20'>";
    $text.="<table>This is in general the recommended way of initialization (<b>except for antiferromagnets, supercells and slabs</b>). <br>
<b>Specify RKMAX and K-mesh, adapted to your problem</b>.<br>
Check STDOUT for errors. When errors occur, run in individual mode (at least the symmetry programs";
    $text.="<tr><td align=left><input type=checkbox value='1' name=expert_spinpol ".($expert_spinpol==1?"checked":"")."$disabled></td><td> select spin-polarized calculation</td></tr>";
    $text.="<tr><td align=left><input type=text size=5 name=expert_red value='$expert_red'  $disabled></td><td> RMT reduction by X % (default: RMT not changed)</td></tr>";
    $text.="<tr><td align=left><input type=text size=5 name=expert_vxc value='$expert_vxc'  $disabled></td><td> VXC option (13=PBE, 5=LDA, 11=WC, 19=PBEsol) [default=13]</td></tr>";
    $text.="<tr><td align=left><input type=text size=5 name=expert_ecut value='$expert_ecut'  $disabled></td><td> energy seperation between core/valence (default: -6.0 Ry)</td></tr>";
    $text.="<tr><td align=left><input type=text size=5 name=expert_rkmax value='$expert_rkmax'  $disabled></td><td> RKMAX  (default: 7.0) <A HREF='http://www.wien2k.at/reg_user/faq/rkmax.html' TARGET=rkmax>Click here for more info</A>)</td></tr>";
    $text.="<tr><td align=left><input type=text size=5 name=expert_fermit value='$expert_fermit'  $disabled></td><td> use TEMP with smearing by X Ry (default: TETRA)</td></tr>";
#    $text.="<tr><td align=left><input type=text size=5 name=expert_mix value='$expert_mix'  $disabled></td><td>set mixing to X  (default: 0.2)</td></tr>";
    $text.="<tr><td align=left><input type=text size=5 name=expert_numk value='$expert_numk'  $disabled ></td><td> use X k-points in full BZ (default: 1000; <A HREF='http://www.wien2k.at/reg_user/faq/kgen.html' TARGET=kgen>Click here for more info</A>)</td></tr> )</td></tr>";


    if(defined($doit) && $errtext!~/.+/)
    {
	$text.="<tr><td>&nbsp;</td><td><font color='#FF0000'><b> Your input seems to be ok and you can start the initialization</b></FONT></td></tr>";
	$text.="<tr><td>&nbsp;</td><td><INPUT TYPE=SUBMIT VALUE='RUN BATCH INITIALISATION'></td></tr>";
    }
    else
    {
	$text.="<tr><td>&nbsp;</td><td><INPUT TYPE=SUBMIT VALUE='CHECK BATCH VALUES'></td></tr>";
    }
    $text.="</table></FORM>";
    $text.="</td></tr>";
    if($err)
    {
	$text.="<tr><td><font color='#FF0000'><b>$errtext</b></FONT></td></tr>";
    }
    else
    {
	$spinpol=($expert_spinpol==1)?"on":"";
	$SESSION_EXPERT_RED=$expert_red;
	$SESSION_EXPERT_VXC=$expert_vxc;
	$SESSION_EXPERT_ECUT=$expert_ecut;
	$SESSION_EXPERT_RKMAX=$expert_rkmax;
	$SESSION_EXPERT_FERMIT=$expert_fermit;
#	$SESSION_EXPERT_MIX=$expert_mix;
	$SESSION_EXPERT_NUMK=$expert_numk;
#        $complex="CHECKED" if ( -e "$DIR/$CASE.in1c" );
	&SaveSession();
    }
    return $text;
}
