#!/usr/bin/perl

require "../../libs/w2web.pl";
#$debug=1;
$spin="up";
$myspinopt="";

&GetInput;
&GetSession;
$prefspace="scf";
&GetPrefs();

$OUT .= "<h2>Optical properties</h2>";

$next="continue with optics";
$nexturl="/exec/optic.pl?SID=$SID";
$nextinteractive=1;

&InitTask();
&RequiredFile("inop");
&RequiredFile("injoint");
&RequiredFile("inkram");


$OUT.="<TABLE>";

if ($plot) {
	$OUT .=  <<__STOP__;
<TR><TD class="task">
<A HREF="$nexturl">Show full menu</A>
</TD></TR>
__STOP__

} else {

	$OUT .=  <<__STOP__;
<TR><TD class="taskoption">
<FORM ACTION="/util/edit.pl">
__STOP__
&PassHiddenParms;
$OUT .=  <<__STOP__;
<b>Optional steps:</b><br>
<INPUT NAME=file VALUE="$DIR/$CASE.in1$filec" TYPE=HIDDEN>
<INPUT TYPE=HIDDEN NAME="spin" VALUE="$spin">
<INPUT TYPE=SUBMIT VALUE="edit $CASE.in1$filec">
Edit $CASE.in1$filec and specify a larger E-max (bottom of file)
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>

<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__
&PassHiddenParms;
$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="x">
<INPUT NAME=prog TYPE=HIDDEN VALUE="kgen">
<INPUT TYPE=SUBMIT VALUE="x kgen">
Prepare a denser k-mesh
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__
&PassHiddenParms;
$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="x">
<INPUT NAME=prog TYPE=HIDDEN VALUE="lapw1">
$myspin
<INPUT TYPE=SUBMIT VALUE="x lapw1  $myspinopt $mypara">
Create eigenvalues at denser k-mesh or higher E-max
&nbsp;
__STOP__
    if($spinpol=~ /CHECKED/ && ! $PREFS{'so'} ) {
	$OUT .=  "<INPUT NAME=orb TYPE=CHECKBOX $PREFS{'orb'}>&nbsp;orb&nbsp";
}
$OUT .=  <<__STOP__;
$ni
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
__STOP__
    if($spinpol=~ /CHECKED/ ) {
 $otherspin = "dn" if ($spin =~ /up/) ;
 $otherspin = "up" if ($spin =~ /dn/) ;
$OUT .=  <<__STOP__;
<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__
&PassHiddenParms;
$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="x">
<INPUT NAME=prog TYPE=HIDDEN VALUE="lapw1">
<INPUT TYPE=HIDDEN NAME=spin VALUE=$otherspin>
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
<INPUT TYPE=SUBMIT VALUE="x lapw1  -$otherspin $mypara">
for both spins
__STOP__
    if($spinpol=~ /CHECKED/ && ! $PREFS{'so'} ) {
	$OUT .=  "<INPUT NAME=orb TYPE=CHECKBOX $PREFS{'orb'}>&nbsp;orb&nbsp";
}
$OUT .=  <<__STOP__;
$ni
</FORM>
__STOP__
}

if( $PREFS{'so'})  {
    $my_spinp = "no" ;
    $my_spinp = "yes" if ($spin =~ /dn/) ;
    if ($my_spinp =~ /no/) {
$OUT .=  <<__STOP__;
<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__
&PassHiddenParms;
$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="x">
<INPUT NAME=prog TYPE=HIDDEN VALUE="lapwso ">
<INPUT TYPE=SUBMIT VALUE="x lapwso $myspinopt $mypara">
$myspin
Create eigenvalues with spin-orbit coupling
&nbsp;
__STOP__
    if($spinpol=~ /CHECKED/ ) {
	$OUT .=  "<INPUT NAME=orb TYPE=CHECKBOX $PREFS{'orb'}>&nbsp;orb&nbsp";
}
$OUT .=  <<__STOP__;
$ni
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
__STOP__
    } 
}
$OUT .=  <<__STOP__;
</TD></TR>

<TR><TD class="task">
<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__
&PassHiddenParms;
$OUT .=  <<__STOP__;
<b>Required steps:</b><br>
<INPUT NAME=precmd TYPE=HIDDEN VALUE="x">
<INPUT NAME=prog TYPE=HIDDEN VALUE="lapw2 -fermi ">
<INPUT TYPE=SUBMIT VALUE="x lapw2 -fermi  $myspinopt $mypara">
$myspin
Calculate weights
<INPUT NAME=so TYPE=CHECKBOX $PREFS{'so'}>&nbsp;so&nbsp;
$ni
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>

<TR><TD class="task">
<FORM ACTION="/util/edit.pl">
<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT NAME=file VALUE="$DIR/$CASE.inop" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="edit $CASE.inop">
 (select number of choices, which depends on your symmetry)
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>


<TR><TD class="task">
<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__
&PassHiddenParms;
$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="x">
<INPUT NAME=prog TYPE=HIDDEN VALUE="optic">
<INPUT TYPE=SUBMIT VALUE="x optic  $myspinopt $mypara">
$myspin
Calculate optics matrixelements
<INPUT NAME=so TYPE=CHECKBOX $PREFS{'so'}>&nbsp;so&nbsp;
$ni
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>

<TR><TD class="task">
<FORM ACTION="/util/edit.pl">
<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT NAME=file VALUE="$DIR/$CASE.injoint" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="edit $CASE.injoint">
[select columns (as in inop); for metals select SWITCH (6 and then 4)]
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>


<TR><TD class="task">
<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__
&PassHiddenParms;
$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="x">
<INPUT NAME=prog TYPE=HIDDEN VALUE="joint">
$myspin
<INPUT TYPE=SUBMIT VALUE="x joint  $myspinopt">
Calculate epsilon-2 
$ni
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>


<TR><TD class="task">
<FORM ACTION="/util/edit.pl">
<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT NAME=file VALUE="$DIR/$CASE.outputjoint$spin" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="view $CASE.outputjoint$spin">
 [For metals: find Plasma frequency after switch 6 in $CASE.injoint]
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>

<TR><TD class="task">
For metals: Before continuing with KRAM, you must (re)run joint with SWITCH 4 !
</TD></TR>

__STOP__

if ( $myspinopt =~ /-up/ || $myspinopt =~ /-dn/ ) {
$OUT .=  <<__STOP__;
<TR><TD class="task">
<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__
&PassHiddenParms;
$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="">
<INPUT NAME=prog TYPE=HIDDEN VALUE="addjoint-updn_lapw">
<b>You must have done all steps above for BOTH spins before this step:</b><br>
<INPUT TYPE=SUBMIT VALUE="addjoint-updn_lapw">
Add spin-up and dn epsilon-2 .
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>
__STOP__
}
$OUT .=  <<__STOP__;

<TR><TD class="task">
<FORM ACTION="/util/edit.pl">
<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT NAME=file VALUE="$DIR/$CASE.inkram" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="edit $CASE.inkram">
[select broadening, for metals: insert plasma frequencies]
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>

<TR><TD class="task">
<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__
&PassHiddenParms;
$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="">
<INPUT NAME=prog TYPE=HIDDEN VALUE=" x kram">
<INPUT TYPE=SUBMIT VALUE="x kram ">
Calculate optical constants by Kramers-Kronig 
$ni
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>

__STOP__
}

if($plot){
	$OUT .= <<__STOP__;
<b>We are in plot mode</b><br>
<TR><TD class="task">
__STOP__
	if($doit) {

		$plotfile="$tempdir/$SID-$$";
		$infile="$DIR/$CASE.";
		$titline=1;
		$delline=0;
                        $seljointupdn="";
                        $seljoint="";
                        $seleps="";
                        $selsigmak="";
                        $selintra="";
                        $seleloss="";
                        $selsum="";
                        $col2="";
                        $col3="";
                        $col4="";
                        $col5="";
                        $col6="";
                        $col7="";
    if ($col =~ /2/) {
                        $col2="selected";
		} elsif ($col =~ /3/) {
                        $col3="selected";
		} elsif ($col =~ /4/) {
                        $col4="selected";
		} elsif ($col =~ /5/) {
                        $col5="selected";
		} elsif ($col =~ /6/) {
                        $col6="selected";
		} elsif ($col =~ /7/) {
                        $col7="selected";
		} 
    if ($selfile =~ /jointupdn/) {
			$infile.="joint$updn";
			$titline=2;
			$delline=3;
                        $seljointupdn="selected";
		} elsif ($selfile =~ /joint/ ) {
			$infile.="joint";
			$titline=2;
			$delline=3;
                        $seljoint="selected";
		} elsif ($selfile =~ /epsilon/ ) {
                        $seleps="selected";
			$infile.="epsilon";
			$titline=5;
			$delline=6;
			$plotoptions="set xzeroaxis";
		} elsif ($selfile =~ /sigmak/ ) {
			$infile.="sigmak";
			$titline=7;
			$delline=8;
                        $selsigmak="selected";
		} elsif ($selfile =~ /sigma_intra/ ) {
			$infile.="sigma_intra";
			$titline=3;
			$delline=4;
                        $selintra="selected";
		} elsif ($selfile =~ /eloss/ ) {
			$infile .= "eloss";
			$titline = 4;
			$delline = 6;
                        $seleloss="selected";
		} elsif ($selfile =~ /sumrules/ ) {
			$infile .= "sumrules";
			$titline = 1;
			$delline = 0;
                        $selsum="selected";
		}


	
		$test = qx(wc -l $infile);
		if ($test == 0) {
			$OUT .= "$infile is empty - no plot produced";
		} else {

			$tmp1 = "$DIR/:opt1";
			$tmp2 = "$DIR/:opt2";

			$units  = "ev";
			$xlabel = "Energy [eV]";
			$axis   = "yzeroaxis";
	
			$umps = qx(sed "1,${delline}d" $infile >$tmp1);
			$tmp  = qx(cat $infile | head -$titline | tail -1|cut -c1-8,15-99);
			@ylabels = split(" ",$tmp);
			$ylabel = $ylabels[$col-1];
			$title = "$infile column $col";

    unless(open(FILE,">$tmp2")) {
      &CGIError("Can't write file $fname.\n");
      exit;
    }
    print FILE <<__STOP__;
show all
set terminal png
set output '$plotfile.png'
set title '$title'
set style data lines
set xrange [$xmin:$xmax]
set yrange [$ymin:$ymax]
set xlabel "$xlabel"
set ylabel "$ylabel"

set $axis
$plotoptions
plot "$tmp1" using 1:$col  title "$fname"
set terminal postscript
set output '$plotfile.ps'
replot
__STOP__
			close(FILE);
			$umps = qx(cd $DIR;gnuplot $tmp2 2>&1);
			$OUT .= "<br><IMG SRC=/tmp/$SID-$$.png><br clear=all><br>";
			$OUT .= "<A HREF=/tmp/$SID-$$.ps>Download hardcopy in PostScript format</A
>";

	
		    }
#		$OUT .= $myform1;
#		&PassHiddenParms;
#		$OUT .= $myform2
	}
$myform1 =  <<__STOP__;
<FORM ACTION=/exec/optic.pl METHOD=POST>
__STOP__
$myform2 =  <<__STOP__;
<SELECT NAME="selfile">
<option $seljointupdn value="jointupdn">$CASE.joint$updn
<option $seljoint value="joint">$CASE.joint
<option $seleps value="epsilon">$CASE.epsilon
<option $selsigmak value="sigmak">$CASE.sigmak
<option $selintra value="sigma_intra">$CASE.sigma_intra
<option $seleloss value="eloss">$CASE.eloss
<option $selsum value="sumrules">$CASE.sumrules
</SELECT>
<SELECT NAME="col">
<option $col2 value=2>2
<option $col3 value=3>3
<option $col4 value=4>4
<option $col5 value=5>5
<option $col6 value=6>6
<option $col7 value=7>7
</SELECT>
<INPUT TYPE=hidden NAME=doit VALUE="1">
<INPUT TYPE=hidden NAME=plot VALUE="1">
<INPUT TYPE=SUBMIT VALUE="plot">
Plot optical properties
<br>
Set ranges (optional):
<br>
xmin=<INPUT NAME=xmin VALUE="$xmin" SIZE=5>
xmax=<INPUT NAME=xmax VALUE="$xmax" SIZE=5>
ymin=<INPUT NAME=ymin VALUE="$ymin" SIZE=5>
ymax=<INPUT NAME=ymax VALUE="$ymax" SIZE=5>
<INPUT TYPE=HIDDEN NAME="spin" VALUE="$spin">
</FORM>
</TD></TR>
__STOP__

#old doit beginn
# else {
		$OUT .= $myform1;
		&PassHiddenParms;
		$OUT .= $myform2

#	}
} else {
	$OUT .= <<__STOP__;
<TR><TD class="task">
<FORM ACTION=/exec/optic.pl METHOD=POST>
__STOP__
&PassHiddenParms;
    opendir(DIR1, $DIR);
    @files = sort(readdir(DIR1));
    closedir(DIR1);
$OUT .=  <<__STOP__;
<INPUT TYPE=hidden NAME=plot VALUE="1">
$myspin
<INPUT TYPE=SUBMIT VALUE="opticplot">
Plot optical properties &nbsp;&nbsp;&nbsp; or &nbsp;&nbsp;&nbsp; download ASCII files for plotting with your own plotting program <br> &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
__STOP__
    foreach (@files) {
        if (!($_ =~ /^\.$/ )) {
            if ($dir =~ /\/$/) {
                $F = $dir . $_;
            } else {
                $F = $dir . "/" . $_;
            }
                if ($_ =~ /\.joint.*$/ ) { 
                    $OUT .= "<a href=\"/util/download.pl?SID=$SID&file=$DIR/$_\">$_</
a>";}
                if ($_ =~ /\.epsilon.*$/ ) { 
                    $OUT .= "<a href=\"/util/download.pl?SID=$SID&file=$DIR/$_\">$_</
a>";}
                if ($_ =~ /\.sigmak.*$/ ) { 
                    $OUT .= "<a href=\"/util/download.pl?SID=$SID&file=$DIR/$_\">$_</
a>";}
                if ($_ =~ /\.sigma_.*$/ ) { 
                    $OUT .= "<a href=\"/util/download.pl?SID=$SID&file=$DIR/$_\">$_</
a>";}
                if ($_ =~ /\.eloss.*$/ ) { 
                    $OUT .= "<a href=\"/util/download.pl?SID=$SID&file=$DIR/$_\">$_</
a>";}
                if ($_ =~ /\.sumrules.*$/ ) { 
                    $OUT .= "<a href=\"/util/download.pl?SID=$SID&file=$DIR/$_\">$_</
a>";}
    }}
$OUT .= <<__STOP__;
</FORM>
</TD></TR>
__STOP__
}

$OUT .= <<__STOP__;
<TR><TD class="task">
<FORM ACTION="/util/savelapw.pl">
<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT TYPE=HIDDEN NAME="doit" VALUE="1">
<INPUT TYPE=HIDDEN NAME="o" VALUE="1">
<INPUT NAME=redir VALUE="/exec/optic.pl?SID=$SID" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="save_lapw  -optic">
 with name: $indent <INPUT NAME="savename"><br>
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>
__STOP__

$OUT.=<<__STOP__;

</TABLE>
__STOP__


PrintPage("Context",$OUT);


