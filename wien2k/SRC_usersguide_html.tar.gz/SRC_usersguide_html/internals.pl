# LaTeX2HTML 2012 (1.2)
# Associate internals original text with physical files.


$key = q/sec:telnes3-files/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:mixer-in/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:berrypi/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:x_lapw/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:qsplit/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:symmetso/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:gui-config/;
$ref_files{$key} = "$dir".q|11Installation_Dimensioning.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_EngelPRB93/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:structeditor/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Charpin01/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:dftd3-exe/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:userconfig/;
$ref_files{$key} = "$dir".q|11Installation_Dimensioning.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KohlerCPC96/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KrukauJCP06/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:aim-exe/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:tic_super/;
$ref_files{$key} = "$dir".q|10Examples.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_PerdewPRL96/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:eplot/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:orb-dim/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw5/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:plane/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:spaghetti-exe/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:testpara1/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:Cgrace/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:file-flow/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:tio2/;
$ref_files{$key} = "$dir".q|10Examples.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:tic-bandcharacter/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:struct2poscar/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:tic-densel/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_vinet/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:vx-switches/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/cha:utility/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:analyse/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:broadening/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:hf-exe/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:symmetso-exe/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:sumpara-dim/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:qtl/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:mini/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:filtvec-exe/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:setrmt_lapw/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:wien_startup/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_SunPNAS15/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw/;
$ref_files{$key} = "$dir".q|2Basic_concepts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_SinghPRB89/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:patchsymm-exe/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_SchwarzCPC02/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:IRelast/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:rel-quant-number/;
$ref_files{$key} = "$dir".q|6Initialization.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KingSmithPRB93/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_LeePRB88/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_GayACMTMS83/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_AndersenSSC73/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ArmientoPRL13/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_OrtenziPRB12/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Singh/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_DesclauxCPC69/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:struct-file/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw1/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:supercell-exe/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/cha:file-structure/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:join_vectorfiles/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_RomanPerezPRL09/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:mixer-exe/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:afminput/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:init_so/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:tic-dos1/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:struct-creat/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_RuzsinszkyJCTC09/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:lm-combinations2/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:migrate_lapw/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw3-dim/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapwdm-dim/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:rhoplot/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:elast-exe/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:aim-dim/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:hf-in/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:lapw2para/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:pairhess/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_HamadaPRB14/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:performance/;
$ref_files{$key} = "$dir".q|11Installation_Dimensioning.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_CooperPRB10/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_NovakPRB01/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:spacegroup/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapwso-in/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:dstart-exe/;
$ref_files{$key} = "$dir".q|6Initialization.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:min/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:mini-exe/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:optic-dim/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:Tmaker/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:flow_nlvdw/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:optic-exe/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:dipan-exe/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:history/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:prepare_xsf_lapw/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:job-control/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lstart/;
$ref_files{$key} = "$dir".q|6Initialization.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_BoeseJCP00/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:balsac/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:dosplot/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:xspec-in/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_BetzingerPRB10/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_TranPRB11/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:add_columns/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:kram-dim/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_BeckeJCP93/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:flow_eece/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:optic/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:joint-in/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:E_tot/;
$ref_files{$key} = "$dir".q|2Basic_concepts.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:apwbasis/;
$ref_files{$key} = "$dir".q|2Basic_concepts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:irrep/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:nlvdw-in/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_MadsenPRB07/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:orb-in/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:nmr/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_CarmonaEspindolaJCP15/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_AmbroschDraxlPRB95/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:create_add_atom_clmsum_lapw/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw2-dim/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:periodic-table/;
$ref_files{$key} = "$dir".q|B_Periodic_Table.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:dftd3-in/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ZhaoJCP08/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:filtvec/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapwso-dim/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:xspec-exe/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:aim/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:kram-exe/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:symmetry-exe/;
$ref_files{$key} = "$dir".q|6Initialization.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_MattheissPRB86/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:mini-dim/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:qtl-out/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_WeinertJMP81/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:flow_fsm/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_BerlandPRB14/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:cancel_lapw/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:flow_hf/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lcore-dim/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:joint/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:libxc_install/;
$ref_files{$key} = "$dir".q|11Installation_Dimensioning.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:wannier/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_SjostedtSSC00/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_PerdewPRL99/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:ex-switches/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:wien_struct/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:optimize-exe/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:samples/;
$ref_files{$key} = "$dir".q|10Examples.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:lm-combinations/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:specplot/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_JansenPRB84/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:structure_opt/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:fleur2wien/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:telnes2-in/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:tic-dos2/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:afminput-exe/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:clean_lapw/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:dipan-dim/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_SolerPRB89/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:optimize-in/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:mixer/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_StephensJPC94/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_WuPRB06/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KlimesJPCM10/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_BeckePRA88/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:dipan/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:tic-xspec_l3/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:BerryPI/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cha:programs/;
$ref_files{$key} = "$dir".q|6Initialization.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:clminter/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_HirstRPM97/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_VoskoCJP80/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cha:quick-volume-opt/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:filtvec-in/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:flow_spinpol/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_VanVoorhisJCP98/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:IO-files-scf/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:xcrysden/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:kgen-exe/;
$ref_files{$key} = "$dir".q|6Initialization.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KollerPRB12/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:irrep-dim/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Tran17/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:tetra/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:extractaim_lapw/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:nlvdw/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:ec-switches/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw0-exe/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:pairhess-in/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:run_vnonloc_lapw/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:initialization/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:eosfit/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_AmbroschDraxlCPC06/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapwso/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_PerdewPRB92b/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:fccni/;
$ref_files{$key} = "$dir".q|10Examples.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:lapw_unitcell/;
$ref_files{$key} = "$dir".q|2Basic_concepts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_LaskowskiPRB12a/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:dstart/;
$ref_files{$key} = "$dir".q|6Initialization.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_SabatiniPRB13/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_AnisimovPRB91/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:wien_infiles/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:structgen/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Burke15/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw2-in/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:atomic-basis/;
$ref_files{$key} = "$dir".q|2Basic_concepts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_BeckeJCP06/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapwdm-in/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:kgen-dim/;
$ref_files{$key} = "$dir".q|6Initialization.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_StahnPRB01/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_CzyzykPRB94/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:structeditor-exe/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/cha:utilities/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:orb/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_LaskowskiPRB13/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_HammerPRB99/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:visualization/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lcore-in/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_LaskowskiPRB12b/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:testpara2/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:xspec/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:clmextrapol/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:parabolfit/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_WeinertPRB82/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:reduce_rmt_lapw/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:qtl-exe/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_SchwarzLNC96/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:clmcopy-exe/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_MurnaghanPNAS44/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_MadsenPRB01/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:addjoint-updn/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:program_flow/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KrimmelPRB94/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_LaskowskiMetals/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_TranPRB15/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:mixer-dim/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:supercell/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/cha:quick-start/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/cha:init-progs/;
$ref_files{$key} = "$dir".q|6Initialization.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:initphonon/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:online-help/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_AndersenPRB75/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:conv2prim/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_WeintraubJCTC09/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:broadening-in/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lstart-in/;
$ref_files{$key} = "$dir".q|6Initialization.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ZhangPRL98/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:parallel/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KokaljCMS03/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw1-dim/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:ghostbands/;
$ref_files{$key} = "$dir".q|12Trouble_shooting.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:fsgen/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_SlaterPR51/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:irrep-exe/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:apwbasislo/;
$ref_files{$key} = "$dir".q|2Basic_concepts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_TaoPRL03/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw1-klist/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:IO-files/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:init_mbj/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:flow_so/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_LaskowskiPRB14/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:arrows/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapwso-exe/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KaraAC81/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:spinorbit/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:tetra-in/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lstart-dim/;
$ref_files{$key} = "$dir".q|6Initialization.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:basis/;
$ref_files{$key} = "$dir".q|2Basic_concepts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KoellingJPCS72/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cha:installation/;
$ref_files{$key} = "$dir".q|11Installation_Dimensioning.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KriegerPLA90a/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:lapw1para/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:E_xc/;
$ref_files{$key} = "$dir".q|2Basic_concepts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapwdm-exe/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:nlvdw-exe/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw3/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:xspec-dim/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lattice-parameters/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:calLa/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:x_nmr/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ErikssonJPCM89/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KlimesPRB11/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:sgroup-exe/;
$ref_files{$key} = "$dir".q|6Initialization.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:elnes-exe/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:dstart-dim/;
$ref_files{$key} = "$dir".q|6Initialization.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:eosfit6/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_YanchitskyCPC01/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:xc-switches/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_WimmerPRB81/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:dftd3/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_PaierJCP06/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:requirements/;
$ref_files{$key} = "$dir".q|11Installation_Dimensioning.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:mBJ/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:analysephonon/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:dosplot2/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:IO-files-utility/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:phonon/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:program-flow/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/cha:introduction/;
$ref_files{$key} = "$dir".q|1Introduction.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lstart-exe/;
$ref_files{$key} = "$dir".q|6Initialization.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:kram-in/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:properties/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_MarksPRB08/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:kgen/;
$ref_files{$key} = "$dir".q|6Initialization.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw1-exe/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:sumpara/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_TranPRB06/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:wien_main/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_GrimmeJCP10/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:tetra-dim/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:further_examples/;
$ref_files{$key} = "$dir".q|10Examples.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:dos_e/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KunesPRB01/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:installation/;
$ref_files{$key} = "$dir".q|11Installation_Dimensioning.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:spaghetti-in/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:scf-calc/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_BlahaJCP09/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:sumpara-exe/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:restore_lapw/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:vec2old/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:tic-bandstructure/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:eplot/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/cha:trouble/;
$ref_files{$key} = "$dir".q|12Trouble_shooting.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_BeckeJCP90/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:loc-rot/;
$ref_files{$key} = "$dir".q|A_Local_rotation.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw1-in/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:xyz2struct/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:core/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:Curve/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:broadening-exe/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:clmcopy/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:filtvec-dim/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:LOs/;
$ref_files{$key} = "$dir".q|2Basic_concepts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_BrooksPB85/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:interface/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_HaasPRB10/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_BaderAIM/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Novak97/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw5-dim/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_HaasPRB11/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_TaoPRL16/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_SchwarzJPF79/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:check_lapw/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ReshakJAC13/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_WellendorffJCP14/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:save/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_vanLeeuwenPRA94/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:scf-file/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_HohenbergPR64/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:lattice-type/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:gibbs/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_DionPRL04/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:telnes3-practical/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:vnonloc/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:potential/;
$ref_files{$key} = "$dir".q|2Basic_concepts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:makescratch/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/Exchybrid/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_PardiniCPC12/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_TranPRB07/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lcore-exe/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:opticplot/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:basis-interstitial/;
$ref_files{$key} = "$dir".q|2Basic_concepts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:flow_dftd3/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:nn-exe/;
$ref_files{$key} = "$dir".q|6Initialization.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapwdm/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_YuPRB91/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:flow_orb/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:flow_afm/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:pairhess-exe/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:tic_structure/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:dft/;
$ref_files{$key} = "$dir".q|2Basic_concepts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_MarquesCPC12/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_HendersonJCP08/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Sofo01/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:clmcopy-in/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_DesclauxCPC75/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_BlochlPRB94/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:optic-in/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Table64/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:kram/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_MarksJCTC13/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:flow_states/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:rho_sigma/;
$ref_files{$key} = "$dir".q|2Basic_concepts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_PerdewPRL08/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:elnes/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Novak06/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_PerdewPRB92a/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ConstantinPRB16/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:orb-exe/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw7-exe/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:grepline_lapw/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_BlahaPRL85/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:dipan-in/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_BeckePRA89/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:wien_densel/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_AbtPB94/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:joint-dim/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Jamal2016/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:optimize/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:qtl-in/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_SunJCP13/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:joint-exe/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_HamprechtJCP98/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:init_lapw/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:run_lapw/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Novak01/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_LaskowskiSulfur/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw2-exe/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:makestruct/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw7-dim/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_SchwarzJPF80/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw2/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:elast-in/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_FabianoPRB10/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:configure_int_lapw/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_NeckelMAS75/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw7-in/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_LaskowskiGallates/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:dimensioning/;
$ref_files{$key} = "$dir".q|11Installation_Dimensioning.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:patchsymm/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:scfmonitor/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:add_columns_new/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_PerdewPRL09/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw0/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:symmetry/;
$ref_files{$key} = "$dir".q|6Initialization.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_MacDonaldJPC80/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:kohn-sham/;
$ref_files{$key} = "$dir".q|2Basic_concepts.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_VydrovJCP10/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cha:scf-progs/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_LiechtensteinPRB95/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:hf/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:save_lapw/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:hex2rhomb/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_BlahaIJQC83/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw7/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Abt97/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_LeePRB10/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:new-case/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KohnPR65/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:cif2struct/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_HeydJCP03/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:struct2cif/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw3-exe/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw5-in/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KoellingJPF75/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:tio2-locrot/;
$ref_files{$key} = "$dir".q|A_Local_rotation.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_TranPRL09/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_BoeseJCP01/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_crosssections/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:nn/;
$ref_files{$key} = "$dir".q|6Initialization.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:mini-in/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:elast/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_poirier/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Karsai2017/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cha:basics/;
$ref_files{$key} = "$dir".q|2Basic_concepts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:Unsupported_software/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_TranPLA12/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:expand_lapw/;
$ref_files{$key} = "$dir".q|11Installation_Dimensioning.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw5-exe/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:tic-densel1/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:tetra-exe/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:xcrysden/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_AnisimovPRB93/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_SunPRL15/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:eigenhess/;
$ref_files{$key} = "$dir".q|9Utility_Programs.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_RestaPRL93/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:spaghetti/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KoellingJPC77/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw0-dim/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:sgroup/;
$ref_files{$key} = "$dir".q|6Initialization.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:vc-switches/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:site_config/;
$ref_files{$key} = "$dir".q|11Installation_Dimensioning.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_MostofiCCP08/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:IO-files-init/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_WeiPRB85/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ArmientoPRB05/;
$ref_files{$key} = "$dir".q|Bibliography.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:instgen_lapw/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:naming-conventions/;
$ref_files{$key} = "$dir".q|3Quick_Start.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:lapw0-in/;
$ref_files{$key} = "$dir".q|7SCF_cycle.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:testpara/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:scf_flow/;
$ref_files{$key} = "$dir".q|4Files_Program.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:aim-in/;
$ref_files{$key} = "$dir".q|8Analysis_Properties.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:init_hf/;
$ref_files{$key} = "$dir".q|5Shell_scripts.html|; 
$noresave{$key} = "$nosave";

1;

